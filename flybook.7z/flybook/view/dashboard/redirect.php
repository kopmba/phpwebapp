<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 
	$userid = substr(strstr($request_uri, '&'), 6);

    if (stristr($request_uri, 'profile/settings.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/profile/settings.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'profile/profile.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/profile/profile.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'profile/create.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/profile/create.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'product/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/product/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }


    if (stristr($request_uri, 'commission/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/commission/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'trip/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'trip/listddeparture.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/listddeparture.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	 if (stristr($request_uri, 'trip/listdreturn.php')==true){

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/listdreturn.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	if (stristr($request_uri, 'trip/listdeparturearrival.php')==true){

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/listdeparturearrival.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'trip/listprice.php')==true){

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/listprice.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'trip/liststatus.php')==true){

        $uri = 'Location: http://localhost/xampp/flybook/view/trip/liststatus.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	if (stristr($request_uri, 'index.php') == true) {

        $uri = 'Location: http://localhost/xampp/flybook/index.php';
		header($uri);
		exit;
    }

    else {

        echo "not found url";
    }
?>