<?php
	require('../../appcore/config/dbconfig.php');
    require("../../appcore/auth/auth.php");
        require("../../appcore/controller/controller.php");
        require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	
	$profile = AuthController::login();

    session_start();

    $_SESSION["session"]= $profile['username'];
    $username = $_SESSION["session"];

    $tdb = Util::getDb();
    $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

    print_r($user);

    if($user['roleid'] == '1') {
        $uri = 'Location: http://localhost/xampp/flybook/view/dashboard/dashboard-admin.php?user=';
		$url = "$uri$username";
		header($url);
		exit;
    }
	
	if ($user['roleid'] == '3') {
        $uri = 'Location: http://localhost/xampp/flybook/view/dashboard/dashboard-client.php?user=';
		$url = "$uri$username";
		header($url);
		exit;
    }
	
	if($user['roleid'] == '4') {
        $uri = 'Location: http://localhost/xampp/flybook/view/dashboard/dashboard-connector.php?user=';
		$url = "$uri$username";
		header($url);
		exit;
    }
	

    
?>