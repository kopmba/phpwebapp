<?php

     class ProductController extends Controller {

            public static function addToCart() {
                   //get db server
				$db = Util::getDb();
				
				$date_created = new DateTime();
				$userid = $_POST['userid'];
				$id = $_POST['id'];
				$date_created = new DateTime();
				$product = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
				//$commandpayed = Controller::findOne($db->getDbserver(), 'commandpayed', 'consumerid', $userid);
				//$nb = 0;
				$stamp = $date_created->getTimestamp();
;
				$stref = "$userid$stamp";
				//$refcmd = $commandpayed['refcmd'];
				/*if ($commandpayed == null) {
					$refcmd = sha1($stref);
				}*/
				$refcmd = sha1($stref);
				//$date_created = new DateTime();
				
				$productpf = array();
				$productpf['refcmd'] = $refcmd;
				$productpf['productid'] = $id;
				$productpf['qty'] = 1;
				$productpf['amount'] = $product['price'];
				$productpf['state'] = 1;
				$productpf['img'] = $product['imgs'];
				$productpf['created'] = $date_created->format('Y-m-d H:i:s');
				$productpf['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'productpayedfromcart', 'ppfcid', $productpf);
				
				
            }
			
			public static function buy() {
                   //get db server
				$db = Util::getDb();
				
				$date_created = new DateTime();
				$uid = $_POST['userid'];
				$id = $_POST['refcmd'];
				$cid = $_POST['cid'];
				$oid = $_POST['oid'];
				$tamount = $_POST['amount'];
				$products = Controller::find($db, 'productpayedfromcart');
				
				$date_created = new DateTime();
				
				
				$command = array();
				$command['refcmd'] = $id;
				$command['consumerid'] = $cid;
				$command['producerid'] = $oid;
				$command['conectorid'] = 5;
				$command['totalamount'] = $tamount;
				$command['_status'] = 'PAID';
				$command['created'] = $date_created->format('Y-m-d H:i:s');
				$command['edited'] = $date_created->format('Y-m-d H:i:s');
				
				

				Controller::save($db, 'commandpayed', 'cpid', $command);
				
				foreach ($products as $key => $value) {
					if($value[1] == $id) { 
						$value[5] = 0;
						Controller::update($db, 'productpayedfromcart', 'ppfcid', $value[0], $value);
					}
				}
				
				
            }
			
			public static function ship() {
                   //get db server
				$db = Util::getDb();
				
				$date_created = new DateTime();
				$trid = $_POST['shipper'];
				$id = $_POST['id'];
				$status = 'TO SHIP';
								
				$date_created = new DateTime();
				
				$ship = array();
				$ship['cmdpayedid'] = $id;
				$ship['transporterid'] = $trid;
				
				$product['_status'] = $status;
				$ship['reason'] = $oid;
				$product['created'] = $date_created->format('Y-m-d H:i:s');
				$product['edited'] = $date_created->format('Y-m-d H:i:s');
				
				

				Controller::save($db, 'shipping', 'shid', $ship);
				
				
				
            }

			public static function createProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

				$cname = $_POST['category'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'caid', $cname);
				
				$date_created = new DateTime();
				
				$product = array();
				$product['brand'] = $_POST['brand'];
				$product['pname'] = $_POST['pname'];
				$product['category'] = $category['caid'];
				$product['subcategory'] = $_POST['subcategory'];
				$product['description'] = $_POST['description'];
				$product['price'] = $_POST['price'];
				$product['year'] = $_POST['year'];
				$product['qty'] = $_POST['qty'];
				$product['imgs'] = '';
				$product['ownerid'] = $profile['proid'];
				$product['created'] = $date_created->format('Y-m-d H:i:s');
				$product['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'product', 'pid', $product);

			}

			public static function updateProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$pid = $_POST['pid'];
				$product = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid);

				$cname = $_POST['category'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'name', $cname);
				
				$date_created = new DateTime();
				
				$updated_product = $product;
				$updated_product['brand'] = $_POST['brand'];
				$updated_product['pname'] = $_POST['pname'];
				$updated_product['category'] = $category['caid'];
				$updated_product['subcategory'] = $_POST['subcategory'];
				$updated_product['description'] = $_POST['description'];
				$updated_product['price'] = $_POST['price'];
				$updated_product['year'] = $_POST['year'];
				$updated_product['qty'] = $_POST['qty'];
				$updated_product['edited'] = $date_created->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'product', 'pid', $pid, $updated_product);
				
            }
            
            public static function removeProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];

				$pid = $_POST['pid'];
				$product = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid);
					 
				Controller::delete($db->getDbserver(), 'product', 'pid', $pid);
			}

     }

?>
