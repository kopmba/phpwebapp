<?php

	//require('encoder.php');
	
	class Util {
	
		public static function getDb() {
			$db = new Dbconfig();

			$db->setPassword("");
			$db->setUsername("root");
			$db->setHostname("localhost");
			$db->setDbname("flybook");
			$db->setPort("3306");
			
			//echo "db exist";
			Dbconfig::getConnection('mysql', $db);
			return $db;
		}	
			
	}

?>
