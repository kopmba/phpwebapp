-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 13 mai 2022 à 19:54
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `flybook`
--

--
-- Structure de la table `booking`
--

CREATE TABLE `booking` (
  `bid` mediumint(9) NOT NULL,
  `bookerid` mediumint(9) NOT NULL,
  `bstatus` varchar(40) DEFAULT NULL,
  `msg` text DEFAULT NULL,
  `checked` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `commission` (
  `coid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) NOT NULL,
  `bookingid` mediumint(9) NOT NULL,
  `amount` varchar(40) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `messagenotification`
--

CREATE TABLE `messagenotification` (
  `mnid` mediumint(9) NOT NULL,
  `bookingid` mediumint(9) NOT NULL,
  `msg` text DEFAULT NULL,
  `checked` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `proid` mediumint(9) NOT NULL,
  `firstname` varchar(80) NOT NULL,
  `lastname` varchar(80) NOT NULL,
  `fullname` varchar(80) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `userid` varchar(80) DEFAULT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` mediumint(9) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id`, `role_name`, `description`, `created`, `edited`) VALUES
(1, 'admin', 'User allowed to updated all the contents', '2020-09-07 09:17:42', NULL),
(2, 'agency', 'Agency allowed to update specific contnets', NULL, NULL);
(3, 'user', 'User allowed to update specific contnets', NULL, NULL);

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL,
  `token` varchar(20) DEFAULT NULL,
  `roleid` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `email`, `password`, `token`, `roleid`, `created`, `edited`) VALUES
('admin', 'admin@homebook.org', 'admin', NULL, 1, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user1', 'user1@homebook.org', '123456', '', 2, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user2', 'user2@homebook.org', 'user', NULL, 2, '2022-05-13 13:56:13', '2022-05-13 13:56:13');

-- --------------------------------------------------------


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
