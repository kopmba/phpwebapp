<?php 

    $url = 'Location: http://localhost/xampp/taxipool/login.php';
    header($url);
    exit;

?>
  
