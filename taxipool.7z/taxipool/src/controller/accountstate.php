<?php

     class CategoryController extends Controller {

			public static function createCategory() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$name = $_POST['name'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$category = array();
				$category['name'] = $name;
				$category['description'] = $description;
				$category['created'] = $date_created->format('Y-m-d H:i:s');
				$category['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'category', 'caid', $category);

			}

			public static function updateCategory() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$caid = $_POST['caid'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'caid', $caid);

				$name = $_POST['name'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$updated_category = $category;
				$updated_category['name'] = $name;
				$updated_category['description'] = $description;
				$updated_category['edited'] = $date_created->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'category', 'caid', $caid, $updated_category);
				
            }
            
            public static function removeCategory() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];

				$caid = $_POST['caid'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'caid', $caid);
					 
				Controller::delete($db->getDbserver(), 'category', 'caid', $caid);
			}

    }

?>
