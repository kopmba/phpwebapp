<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');

?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);

        $administrationinfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
    ?>

    <p>Do you want to sign that information from administration ? </p>
    <form method="post" action=<?php echo "helper/delete.php?user=$username&id=$id" ?>>
    <input type="text" name="id" hidden value=<?php echo $administrationinfo['admid'] ?>>
	<input type="text" name="validator" hidden value=<?php echo $profile['firmid'] ?>>
        <a class="button" href=<?php echo "list.php?user=$username" ?>>Cancel</a>
        <input type="submit" value="Sign"/>

    </form>
</div>