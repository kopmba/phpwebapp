<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');


?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        echo $id; 
        echo $userid;
        
        $administrationinfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
        
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="admid" hidden value=<?php echo $id ?>>         
        <input type="text" name="publisher" hidden  value=<?php echo $administrationinfo['publisherid'] ?>> 
		
        <div id="profile">
		   <h3>Administration Information</h3>
		   <input type="text" name="address" value=<?php echo $administrationinfo['address'] ?> >
		   <input type="text" name="phone" value=<?php echo $administrationinfo['phone'] ?> >
		   <input type="text" name="city" value=<?php echo $administrationinfo['city'] ?> >
		   <input type="text" name="country" value=<?php echo $administrationinfo['country'] ?> >
		   <textarea type="text" name="description"><?php echo $administrationinfo['description'] ?></textarea> 
		</div>
          
        
        <input type="submit" value="Update"/>

    </form>
</div>