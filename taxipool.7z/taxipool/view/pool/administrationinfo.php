<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');
    
?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        
        $administrationinfo = Controller::findOne($tdb->getDbserver(), 'administrationinfo', 'admid', $id);
    ?>

    <div>
        <p>About administration :<?php  echo $administrationinfo['city'] ?>, <?php  echo $administrationinfo['country'] ?>, <?php  echo $administrationinfo['phone'] ?> &nbsp;&nbsp;
		<br>
		<p><?php  echo $administrationinfo['description'] ?></p>
		<a href=<?php echo "administrationinfo.php?user=$username&id=$administrationinfo[0]" ?>>Voir</a> 
		| <a href=<?php echo "edit.php?user=$username&id=$administrationinfo[0]" ?>>Modifier</a> |
			<a href=<?php echo "delete.php?user=$username&id=$administrationinfo[0]" ?>>Supprimer</a>
		<?php if($user['roleid'] == 1 && $administrationinfo['publisherid'] != $profile['firmid']): ?>
			| <a href=<?php echo "edit.php?user=$username&id=$administrationinfo[0]" ?>>Signed</a>
		<?php endif ?></p>
        <p>
            <?php if($user['roleid'] == 1): ?>
                <a href=<?php echo "upload.php?user=$username&id=$administrationinfo[0]" ?>>Add document</a> 
            <?php endif ?>
        </p>
    </div>
    
</div>