
<?php
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
        require("../../appcore/auth/auth.php");
        require("../../appcore/controller/controller.php");
        require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	
	$profile = AuthController::login();
	
	$db = Util::getDb();
	
	$user = Controller::findOne($db->getDbserver(), 'user', 'username', $profile['userid']);
	
	if($user['roleid'] == 1) {
		$username = $profile['userid'];
		$uri = 'Location: http://localhost/xampp/taxipool/view/dashboard/dashboard-admin.php?user=';
		$url = "$uri$username";
	    header($url);
	    exit;
	} 
	
	if($user['roleid'] == 2) {
		$username = $profile['userid'];
		print_r($username);
		$uri = 'Location: http://localhost/taxipool/view/dashboard/dashboard-driver.php?user=';
		$url = "$uri$username";
	    header($url);
	    exit;
	}
	
	if($user['roleid'] == 3) {
		$username = $profile['userid'];
		print_r($username);
		$uri = 'Location: http://localhost/taxipool/view/dashboard/dashboard-passenger.php?user=';
		$url = "$uri$username";
	    header($url);
	    exit;
	}
	
	
?>
