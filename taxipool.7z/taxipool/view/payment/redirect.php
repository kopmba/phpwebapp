<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 
    $id = substr(strstr($request_uri, '&'), 4);
    $userid = substr(strstr($request_uri, '?'), 6);

    if (strcmp($request_uri, 'payment/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/list.php?user=';
		$url = "$uri";
		header($url);
		exit;
    }

    else if (strcmp($request_uri, 'payment/payment.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/payment.php?user=';
		$param = "$userid&id=$id";
	    $url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'helper/create_package.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/create_package.php?user';
		$param = "$userid&id=$id";
	    $url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'helper/create_product.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/create_product.php?user';
		$param = "$userid&id=$id";
	    $url = "$uri$param";
		header($url);
		exit;
    }

    else {

        echo "not found url";
    }
?>