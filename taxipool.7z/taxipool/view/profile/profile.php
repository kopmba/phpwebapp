
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');


?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];
	
        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
		
		$db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $userid);
		
		$user = Controller::findOne($db->getDbserver(), 'user', 'username', $userid);
		
		if($user['roleid'] != ) {
			$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
			$url = "$uri$param";
			header($url);
			exit;	
		}
        
    ?>

    <div id="profile">
	   <h1><?php echo $fullname ?></h1>
	   <div class="title"><?php echo $username ?></div>
	   <p>Réside dans la ville de : <?php echo $data['profile']['city'] ?>, <?php echo $data['profile']['country'] ?></p>
	   <h2>Contact information</h2>
		<ul>
			<li>Adresse : <?php echo $data['profile']['address'] ?></li>
			<li>Tel: <?php echo $data['profile']['phone'] ?></li>
		</ul>
	</div>
</div>