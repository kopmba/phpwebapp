<?php

    require('appcore/config/dbconfig.php');
    require('appcore/controller/controller.php');
    require('src/util/util.php');
?>
<div>
    <?php
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '='), 1);


    ?>
    <menu>
        <a href=<?php echo "view/administrationinfo/list.php?user=$username" ?>>Administrations</a> |
		<a href=<?php echo "view/certifieddocument/list.php?user=$username" ?>>Certified Documents</a> |
		<a href=<?php echo "view/contract/list.php?user=$username" ?>>Contracts</a> |
		<a href=<?php echo "view/firm/list.php?user=$username" ?>>Firms</a> |
		<a href=<?php echo "view/messagenotification/list.php?user=$username" ?>>Messages</a> |
		<a href=<?php echo "view/payment/list.php?user=$username" ?>>Payments</a> |
		<a href=<?php echo "view/profile/list.php?user=$username" ?>>Profiles</a> |
		<a href=<?php echo "view/requestinfo/list.php?user=$username" ?>>RequestersInformation</a> |
		<a href=<?php echo "view/role/list.php?user=$username" ?>>Roles</a> |
		<a href=<?php echo "view/signature/list.php?user=$username" ?>>Signatures</a> |
		<a href=<?php echo "view/user/list.php?user=$username" ?>>Users</a>
    </menu>
</div>