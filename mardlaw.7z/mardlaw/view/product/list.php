<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');


    echo 'product';
?>

<div>
    <?php 

        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        echo "List of products";

        $db = Util::getDb();
        $products = Controller::find($db, 'product');

        $len = count($products);
        echo $len;
        
        if($id && $id >= 0) {
            $products = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
            $len = 1;
        }

    ?>
    <?php if($user['roleid'] == 1): ?>
        <a href="create.php">Ajouter</a>
    <?php endif ?>
    <?php if($len == 1): ?>
        <p>Nom du produit :<?php echo $value[2] ?> &nbsp;&nbsp; <a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>Voir</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$id" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$id" ?>>Supprimer</a><?php endif ?></p>
    <?php endif ?>

    <?php if($len > 1): ?>
        <?php foreach ($products as $key => $value): ?>
            <?php if($id == ''): ?>
                <p>Nom du produit :<?php  echo $value[2] ?> &nbsp;&nbsp; <a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>Voir</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Supprimer</a><?php endif ?></p>
            <?php endif ?>
            <?php if($id != ''): ?>
                <p>Nom du produit :<?php echo $value[2] ?> &nbsp;&nbsp; <?php if($user['roleid'] == 1): ?><a href=<?php echo "edit.php?user=$username&id=$id" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$id" ?>>Supprimer</a><?php endif ?></p>
            <?php endif ?>
        <?php endforeach ?>
    <?php endif ?>
    
</div>