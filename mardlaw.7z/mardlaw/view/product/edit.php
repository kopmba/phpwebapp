<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');


?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        echo $id; 
        echo $userid;
        
        $db = Util::getDb();
        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
        $categories = Controller::find($db, 'category');
        print_r($product);
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="pid" hidden value=<?php echo $id ?>>         
        <input type="text" name="brand" value=<?php echo $product['brand'] ?>>   
        <input type="text" name="pname" value=<?php echo $product['pname'] ?>> 
        <select name="category">
            <?php $catname = Controller::findOne($db->getDbserver(), 'category', 'caid', $product['category']); ?>
            <option><?php echo $catname['name'] ?></option>
            <?php foreach ($categories as $key => $value): ?>
                <option value=<?php echo $value[0] ?>><?php echo $value[1] ?></option>
            <?php endforeach ?>
        </select>
        <input type="text" name="subcategory" value=<?php echo $product['subcategory'] ?>>
        <textarea type="text" name="description"><?php echo $product['description'] ?></textarea>   
        <input type="text" name="price" value=<?php echo $product['price'] ?>>
        <select name="year">
            <option><?php echo $product['year'] ?></option>
            <option>2021</option>
            <option>2020</option>
            <option>2019</option>
            <option>2018</option>
            <option>2017</option>
            <option>2016</option>
            <option>2015</option>
            <option>2014</option>
        </select>
        <input type="number" name="qty" value=<?php echo $product['qty'] ?>>
        <input type="submit" value="Modifier"/>

    </form>
</div>