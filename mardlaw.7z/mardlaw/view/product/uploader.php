
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');

    echo '<pre>';
    $img = $_FILES['img'];

    print_r($img);

    if(!empty($img)) {
        $img_desc = reArrayFiles($img);
        print_r($img_desc);
        foreach($img_desc as $val) {
            $newname = date('YmdHis', time()).rand().'.jpg';
            move_uploaded_file($val['tmp_name'],'./uploads/'.$newname);
        }
        $db = Util::getDb();
        $pid = $_POST['pid'];
        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid);
        $updated_product = $product;
        if($product['imgs'] == '') {
            $data = array("1" => $newname);
            $json = json_encode($data, true);
            $updated_product['imgs'] = "$json";
        } else {
            $newimg = array("1" => $newname);
            $data = array_push(json_decode($product['imgs'], true), $newimg);
            $json = json_encode($data, true);
            $updated_product['imgs'] = "$json";
        }
        Controller::update($db, 'product', 'pid', $pid, $updated_product);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $uri = 'Location: http://localhost/xampp/shop/view/package/list.php?user=';
        $url = "$uri$userid";
        header($url);
        exit;
    }

    function reArrayFiles($file) {
        $file_array = array();
        $file_count = count($file['name']);
        $file_key = array_keys($file);

        for($i=0;$i<$file_count;$i++) {
            foreach($file_key as $val) {
                $file_array[$i][$val] = $file[$val][$i];
            }
        }

        return $file_array;
    }

?>