<?php

    
    require("../../../appcore/config/dbconfig.php");
	require("../../../appcore/controller/controller.php");
	require("../../../src/util/util.php");
	require('../../../src/controller/auth.php');

    
?>