<?php

    
    require("../../appcore/config/dbconfig.php");
	require("../../appcore/controller/controller.php");
	require("../../src/util/util.php");
	require('../../src/controller/auth.php');

    

    
?>

<div>

    <?php

        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);

        //print_r($profile);

        if($profile['role_name'] == 'admin') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-admin.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }
		
		//List of firms
        $db = Util::getDb();
        $firms = Controller::find($db, 'firm');

        //List of requesterinfos
        $requesterinfos = Controller::find($db, 'requesterinfo');

        //List of administrationinfos
        $administrationinfos = Controller::find($db, 'administrationinfo');

        //List of certifieddocuments
        $certifieddocuments = Controller::find($db, 'certifieddocument');

    ?>
	
	<menu>
        <a href=<?php echo "view/administrationinfo/list.php?user=$username" ?>>Administrations</a> <?php echo count($administrationinfos); ?> |
		<a href=<?php echo "view/certifieddocument/list.php?user=$username" ?>>Certified Documents</a> <?php echo count($certifieddocuments); ?> |
		<a href=<?php echo "view/firm/list.php?user=$username" ?>>Firms</a> <?php echo count($firms); ?> |
		<a href=<?php echo "view/requestinfo/list.php?user=$username" ?>>RequestersInformation</a> <?php echo count($requesterinfos); ?>
    </menu>
	
	<p>Welcome <?php echo $profile['fullname'] ?> from <?php echo $profile['name'] ?> ! </p> Click <a href=<?php echo "redirect.php?link=view/profile/settings.php&user=$username" ?>>here</a> to set your profile.
    
</div>