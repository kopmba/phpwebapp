
<?php
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/auth/auth.php");
	require("../../appcore/controller/controller.php");
	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	
	$profile = AuthController::login();
	
	if($profile['role_name'] == "admin") {
		//print_r($data['profile']['role_name']);
		$username = $profile['userid'];
		$uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-admin.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	} else {
		//print_r($data['profile']['role_name']);
		$username = $profile['userid'];
		print_r($username);
		$uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-client.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	}
	
	
?>
