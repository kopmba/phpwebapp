<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/messagenotification.php');


?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);


        $messages = Controller::find($tdb, 'messagenotification');

        $len = count($messages);
		
		if($profile['role_name'] == 'admin') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-admin.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }
        
    ?>
    <?php if($len < 1): ?>
        <p>There are no messages in the platform. Click on "Add" to add new one.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($messages as $key => $value): ?>
			<?php $firm1 = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[1]); ?>
			<?php $firm2 = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[2]); ?>
			<?php if($value[5] == 0 && $value[3] == $profile['firmid']): ?>
				<form method="post" action=<?php echo "checked.php?user=$username&id=$value[0]" ?>>
					<input type="text" name="msg" hidden value=<?php echo $id ?>>
					<p><?php  echo $firm['name'] ?> le <?php  echo $firm['created'] ?> &nbsp;&nbsp;
					<br>
					<a type="submit" style="background-color: orange" href="#"><?php  echo $value[4] ?></a></p>
				</form>
			<?php endif ?>
			<?php if($value[5] == 1 && $value[3] == $profile['firmid']): ?>|
				<p><?php  echo $firm['name'] ?> le <?php  echo $firm['created'] ?> &nbsp;&nbsp;
				<br>
				<a href=<?php echo "messagenotification.php?user=$username&id=$value[0]" ?>><?php  echo $value[4] ?></a></p>
			<?php endif ?>
        <?php endforeach ?>
    <?php endif ?>
    
</div>