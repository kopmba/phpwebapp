<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');
    require('../../../src/controller/messagenotification.php');


    MessageNotificationController::openMessage();
    
    $request_uri = $_SERVER['REQUEST_URI']; 
    $id = substr(strstr($request_uri, '&'), 4);
    $userid = substr(strstr($request_uri, '?'), 6);

    $uri = 'Location: http://localhost/xampp/mardlaw/view/messagenotification/messagenotification.php?user=';
    $param = "$userid&id=$id";
	$url = "$uri$param";
    header($url);
    exit;


    
?>