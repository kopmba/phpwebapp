<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');


?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        
        $db = Util::getDb();
        $category = Controller::findOne($db->getDbserver(), 'category', 'caid', $id);
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username" ?>>
        <input type="text" name="caid" hidden value=<?php echo $category['caid'] ?>>  
        <input type="text" name="name" value=<?php echo $category['name'] ?>>   
        <textarea type="text" name="description"><?php echo $category['description'] ?></textarea>   
        <input type="submit" value="Modifier"/>

    </form>
</div>