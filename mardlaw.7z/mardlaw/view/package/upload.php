<div>
    <?php 

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
    ?>
    <p>Charger un ou plusieurs fichiers</p>

    <form action=<?php echo "uploader.php?user=$userid&id=$id" ?> method="post" enctype="multipart/form-data" multipart="">
        <input type="file" name="img[]" multiple>
        <input type="text" name="paid" hidden value=<?php echo $id ?>>
        <input type="submit" value="Charger">
    </form>

</div>
