<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/package.php');


?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $db = Util::getDb();
        $products = Controller::find($db, 'product');
        $package = Controller::findOne($db->getDbserver(), 'package', 'paid', $id);

        $json_products = json_encode($package['products'], true);
        $json_str = "&$json_products";
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="paid" hidden value=<?php echo $id?>>
        <input type="text" name="pname" placeholder="Libelle" value=<?php echo $package['pname']?>>
        <input type="text" name="price" placeholder="Prix"  value=<?php echo $package['price']?>>
        <textarea type="text" name="description" placeholder="Description"> value=<?php echo $package['description']?></textarea>   

        <p>Ajouter un produit dans la gamme</p>
        <p><select id="product">
            <option>--Veuillez Choisir--</option>
            <?php foreach ($products as $key => $value): ?>
                <option value=<?php echo "$value[0] $value[2]" ?>><?php echo "$value[0] $value[2]" ?></option>
            <?php endforeach ?>
        </select>  |  <input id="qty" type="text">  | <input type="button" onclick="add()" value="Ajouter"><p>
        <ul id="added">
            <?php $products = json_decode($package['products'], true) ?>
            <?php foreach ($products as $key => $value): ?>
                <?php 
                    $product = Controller ::findOne($db->getDbserver(), 'product', 'pid', $value['id']);
                    $pid = $value['id'];
                ?>
                <li>[produit : <?php echo $product['pname'] ?> | quantité : <?php  echo $value['qty'] ?>] <input type="button" id=<?php echo $pid ?> onclick="remove(this)" value="x"></li>
            <?php endforeach ?> 
        </ul>  
        <input id="product_list" type="text" name="products" value=<?php echo $json_str ?> hidden>     
        <input type="submit" value="Modifier"/>

    </form>
</div>
<script>

    function remove(rm) {

        let id = rm.id;
        rm.parentElement.remove();
        let productsForm = document.getElementById('product_list');
        let list = JSON.parse(productsForm.value.substring(1));
        if(typeof list !== 'object') {
            list = JSON.parse(JSON.parse(productsForm.value.substring(1)));
        }
        let arrayAfterRemoving = [];
        for(i=0; i < list.length; i++) {
            if(list[i].id !== parseInt(id)) {
                //method splice here to remove product forgotten
                arrayAfterRemoving.push(list[i]);
            }
        }

        //mise a jour du formulaire
        productsForm.value = "&"+JSON.stringify(arrayAfterRemoving);
    }

    function add() {
        let inputSelect = document.getElementById('product')[document.getElementById('product').value].value;
        let inputList = document.getElementById('product_list');
        let qty = document.getElementById('qty').value;
        let added = document.getElementById('added');

        let pdata = {};


        pdata.id = inputSelect;
        pdata.qty = qty;

        let linode = document.createElement('li');
        let input = document.createElement('input');
        input.type = "button";
        input.value = "x";
        linode.textContent = '[produit : ' + inputSelect + ' | quantité : '+ qty + ']';
        input.id = inputSelect+qty;
        linode.append(input);
        let inputnode = linode.lastElementChild;
        inputnode.addEventListener('click', function() {
            remove(inputnode);
        });

        added.append(linode);

        let list = [];
        if(inputList.value !== '') {
            list = JSON.parse(inputList.value.substring(1));
            if(typeof list !== 'object') {
                list = JSON.parse(JSON.parse(inputList.value.substring(1)));
            }
            list.push(pdata);
        } else {
            list.push(pdata);
        }
        
       
        localStorage.setItem('products', JSON.stringify(list));
        
        inputList.value = "&"+JSON.stringify(JSON.parse(localStorage.getItem('products')));
        localStorage.removeItem('products');
    }
</script>