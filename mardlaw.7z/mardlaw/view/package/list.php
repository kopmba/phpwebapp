<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/package.php');


    echo 'package';
?>

<div>
    <?php 

        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        // print_r($profile);
        $db = Util::getDb();
        $products = Controller::find($db, 'product');

        echo "List of packages";
        echo $id;

        $db = Util::getDb();
        $packages = Controller::find($db, 'package');
        $len = count($packages);
        echo $len;
        
        if($id && $id >= 0) {
            $packages = Controller::findOne($db->getDbserver(), 'package', 'paid', $id);
            $len = 1;
        }
                

    ?>
    <?php if($user['roleid'] == 1): ?>
        <a href="create.php">Ajouter</a>
    <?php endif ?>
    <?php if($len == 1): ?>

        <?php $products = json_decode($packages['products'], true) ?>

        <p>The package name : <?php echo $packages['pname']; ?> </p>

        <p>
            Les produits :
            <ul>
                <?php foreach ($products as $key => $value): ?>
                    <?php 
                        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $value['id']);
                        $pid = $value['id'];
                    ?>
                    <li>nom : <a href=<?php echo "redirect.php?link=view/product/product.php&user=$username&id=$pid" ?>><?php  echo $product['pname'] ?></a> | qty :<?php  echo $value['qty'] ?></li>
                <?php endforeach ?> 
            </ul> 
        </p>

    <?php endif ?>

    <?php if($len > 1): ?>
        <?php foreach ($packages as $key => $value): ?>
            <?php if($id == ''): ?>
                <p>Nom du package :<?php  echo $value[1] ?> &nbsp;&nbsp; <a href=<?php echo "package.php?user=$username&id=$value[0]" ?>>Voir</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Supprimer</a><?php endif ?></p>
                <p>
                    Les produits :
                    <ul>
                        <?php $products = json_decode($value[4], true); ?>
                        <?php foreach ($products as $key => $value): ?>
                            <?php 
                                $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $value['id']);
                                $pid = $value['id'];
                            ?>
                            <li>nom : <a href=<?php echo "redirect.php?link=view/product/product.php&user=$username&id=$pid" ?>><?php  echo $product['pname'] ?></a> | qty :<?php  echo $value['qty'] ?></li>
                        <?php endforeach ?> 
                    </ul> 
                </p>
            <?php endif ?>
            <br><br>
        <?php endforeach ?>
    <?php endif ?>


</div>