<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 
    $id = substr(strstr($request_uri, '&'), 4);
    $userid = substr(strstr($request_uri, '?'), 6);

    if (stristr($request_uri, 'view/package/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/package/list.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'view/package/edit.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/package/edit.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'view/package/created.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/package/create.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'view/package/delete.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/package/delete.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'view/package/package.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/package/package.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'view/product/product.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/product.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'payment/create_package.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/create_package.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'util/upload.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/src/util/upload.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else {

        echo "not found url";
    }
?>