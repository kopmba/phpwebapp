<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/contract.php');


?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        echo "List of data";

        $certifieddocuments = Controller::find($tdb, 'certifieddocument');

        $len = count($certifieddocuments);
        
    ?>
    <?php if($len < 1): ?>
        <p>There are no certifieddocuments in the platform.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($certifieddocuments as $key => $value): ?>
			<?php $payment = Controller::findOne($tdb->getDbserver(), 'payment', 'payid', $value[1]); ?>
			<?php $bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment[1]); ?>
			<?php $contract = Controller::findOne($tdb->getDbserver(), 'contract', 'coid', $payment[3]); ?>
			<?php $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment[2]); ?>	
			<?php $requesterinfo = Controller::findOne($tdb->getDbserver(), 'requesterinfo', 'reid', $contract[1]); ?>
            <?php $requester = Controller::findOne($tdb->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']); ?>
			<?php $signature = Controller::findOne($tdb->getDbserver(), 'signature', 'sigid', $contract[3]); ?>
			<p>About Document :
			Contract specific for the directory<?php  echo $requester['fullname'] ?>, <?php  echo $requester['city'] ?>, <?php  echo $requester['country'] ?> &nbsp;&nbsp;
			<br>
			has been accepted and signed by the firm <?php  echo $firm['name'] ?> from <?php  echo $firm['city'] ?>, <?php  echo $firm['country'] ?> 
			and the bank <?php  echo $bank['name'] ?> from <?php  echo $bank['city'] ?>, <?php  echo $bank['country'] ?> the below date <?php  echo $signature['created'] ?>
			
			<a href=<?php echo "certifieddocument.php?user=$username&id=$value[0]" ?>>Voir</a> 
			<?php if($user['roleid'] == 1 && $bank): ?>|
				<a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a>
			<?php endif ?></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>