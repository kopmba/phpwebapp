<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/contract.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];
        $id = substr(strstr($request_uri, '&'), 4);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
		
		$certifieddocument = Controller::findOne($tdb->getDbserver(), 'certifieddocument', 'cdid', $id);
        
        $payment = Controller::findOne($tdb->getDbserver(), 'payment', 'payid', $certifieddocument[1]);
		$bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment[1]);
		$contract = Controller::findOne($tdb->getDbserver(), 'contract', 'coid', $payment[3]);
		$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment[2]);	
		$requesterinfo = Controller::findOne($tdb->getDbserver(), 'requesterinfo', 'reid', $contract[1]);
		$requester = Controller::findOne($tdb->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']);
		$signature = Controller::findOne($tdb->getDbserver(), 'signature', 'sigid', $contract[3]); 
		$bankid = $bank['fid'];
		$lawid = $firm['fid'];
	?>

    <div>
        
		<p>About Contract :
		Contract specific for the directory<?php  echo $requester['fullname'] ?>, <?php  echo $requester['city'] ?>, <?php  echo $requester['country'] ?> &nbsp;&nbsp;
		<br>
		has been validated and signed by the firm <?php  echo $firm['name'] ?> from <?php  echo $firm['city'] ?>, <?php  echo $firm['country'] ?>
		and the bank <?php  echo $bank['name'] ?> from <?php  echo $bank['city'] ?>, <?php  echo $bank['country'] ?> the below date <?php  echo $signature['created'] ?>
		<a href=<?php echo "list.php?user=$username" ?>>List</a> 
		
    </div>
    
</div>