<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');


?>
<div>
    <?php 
        session_start();
		$request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

    ?>

    <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
            
		<input type="text" name="publisher" hidden value=<?php echo $profile['firmid'] ?>>
		<div id="profile">
		   <h3>Administration Info</h3>
		   <input type="text" name="address" placeholder="Address">
		   <input type="text" name="phone" placeholder="Phone">
		   <input type="text" name="city" placeholder="City">
		   <input type="text" name="country" placeholder="Country">
		   <textarea type="text" name="description" placeholder="Description"></textarea>   
		</div>
       
        <input type="submit" value="Add new"/>

    </form>
</div>