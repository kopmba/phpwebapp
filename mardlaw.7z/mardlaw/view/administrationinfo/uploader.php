
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');

    echo '<pre>';
    $img = $_FILES['img'];

    print_r($img);

    if(!empty($img)) {
        $img_desc = reArrayFiles($img);
        print_r($img_desc);
        foreach($img_desc as $val) {
            $newname = date('YmdHis', time()).rand().'.jpg';
            move_uploaded_file($val['tmp_name'],'./uploads/'.$newname);
        }
        $db = Util::getDb();
        $id = $_POST['id'];
        $administrationinfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
        $administrationinfo['docurl'] = $newname;
        Controller::update($db, 'administrationinfo', 'admid', $id, $administrationinfo);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $uri = 'Location: http://localhost/xampp/mardlaw/view/administrationinfo/list.php?user=';
        $url = "$uri$userid";
        header($url);
        exit;
    }

    function reArrayFiles($file) {
        $file_array = array();
        $file_count = count($file['name']);
        $file_key = array_keys($file);

        for($i=0;$i<$file_count;$i++) {
            foreach($file_key as $val) {
                $file_array[$i][$val] = $file[$val][$i];
            }
        }

        return $file_array;
    }

?>