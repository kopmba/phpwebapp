
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/profile.php');


?>

<div>
    <?php 
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$clientid = substr(strstr($request_uri, '&'), 4);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);
		$client = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'clientid', $username);
		$clients = Controller::find($tdb, 'profile_client');
        print_r($profile);
		
		if($profile['role_name'] == 'user') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-client.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }
        
    ?>
	<?php foreach ($clients as $key => $value): ?>
		<div id="profile">
		   <h5><?php echo $value[5] ?></h5>
		   <br>
		   <h3><?php echo $value[16] ?> - <?php echo $value[17] ?></h3>
		   <div class="title"><?
		   <p>Company located in the city of : <?php echo $value[18] ?>, <?php echo $value[19] ?></p>
		   <h2>Contact information</h2>
			<ul>
				<li>Adress : <?php echo $value[21] ?></li>
				<li>Phone: <?php echo $value[20] ?></li>
			</ul>
		</div>
	<?php endforeach ?>
</div>