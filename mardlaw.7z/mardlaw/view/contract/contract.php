<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/contract.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];
        $id = substr(strstr($request_uri, '&'), 4);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        
        $contract = Controller::findOne($tdb->getDbserver(), 'contract', 'coid', $id);
		$requesterinfo = Controller::findOne($tdb->getDbserver(), 'requesterinfo', 'reid', $contract[1]);
		$bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $contract[2]); 
		$signature = Controller::findOne($tdb->getDbserver(), 'signature', 'sigid', $contract[3]);
		$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $signature[1]);
		$requester = Controller::findOne($tdb->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']);
    
		$bankid = $bank['fid'];
		$lawid = $firm['fid'];
	?>

    <div>
        
		<p>About Contract :
		Contract specific for the directory<?php  echo $requester['fullname'] ?>, <?php  echo $requester['city'] ?>, <?php  echo $requester['country'] ?> &nbsp;&nbsp;
		<br>
		has been validated and signed by the firm <?php  echo $firm['name'] ?> from <?php  echo $firm['city'] ?>, <?php  echo $firm['country'] ?> the below date <?php  echo $signature['created'] ?>
		<a href=<?php echo "list.php?user=$username" ?>>List</a> 
		<?php if($user['roleid'] == 1 && $bank): ?>|
			<a href=<?php echo "edit.php?user=$username&id=$contract[0]" ?>>Modifier</a> |
			<a href=<?php echo "redirect.php?link=mardlaw/payment/create.php?user=$username&id=$contract[0]&bank€=$bankid&lawµ=$lawid" ?>>Add payment</a>
		<?php endif ?></p>
    </div>
    
</div>