<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/firm.php');
    
?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        
        $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $id);
    ?>

    <div>
        <p>About Firm :<?php  echo $firm[1] ?>, <?php  echo $firm[2] ?>, <?php  echo $firm[3] ?> &nbsp;&nbsp;
			<br>
			<p><?php  echo $firm[6] ?></p>
			<a href=<?php echo "firm.php?user=$username&id=$firm[0]" ?>>Voir</a> 
			<?php if($profile['role_name'] == 'admin'): ?>|
				<a href=<?php echo "edit.php?user=$username&id=$firm[0]" ?>>Modifier</a> |
				<a href=<?php echo "delete.php?user=$username&id=$firm[0]" ?>>Supprimer</a>
			<?php endif ?>
		</p>
    </div>
    
</div>