<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/firm.php');

?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];
        $id = substr(strstr($request_uri, '&'), 4);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);

        $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $id);
    ?>

    <p>Do you want to delete the firm ? </p>
    <form method="post" action=<?php echo "helper/delete.php?user=$username&id=$id" ?>>
    <input type="text" name="id" hidden value=<?php echo $id ?>>
        <a class="button" href=<?php echo "list.php?user=$username" ?>>Annuler</a>
        <input type="submit" value="Supprimer"/>

    </form>
</div>