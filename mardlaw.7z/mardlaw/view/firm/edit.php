<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');


?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);

        //print_r($profile);

        if($profile['role_name'] == 'user') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-client.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }

        $id = substr(strstr($request_uri, '&'), 4);

        echo $id; 
        echo $userid;
        
        $firm = Controller::findOne($db->getDbserver(), 'firm', 'fid', $id);
        
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="admid" hidden value=<?php echo $id ?>>         
		
        <div id="profile">
		   <h3>Firm Information</h3>
		   <input type="text" name="name" value=<?php echo $firm['name'] ?> >
		   <input type="text" name="address" value=<?php echo $firm['address'] ?> >
		   <input type="text" name="phone" value=<?php echo $firm['phone'] ?> >
		   <input type="text" name="city" value=<?php echo $firm['city'] ?> >
		   <input type="text" name="country" value=<?php echo $firm['country'] ?> >
		   <select name="firmType">
				<option><?php echo $firm['firmType'] ?></option>
				<option value="Law">Law</option>
				<option value="Bank">Bank</option>
		   </select>
		</div>
          
        
        <input type="submit" value="Update"/>

    </form>
</div>