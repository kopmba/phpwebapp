<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


    echo 'payment';
?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        

        $id = substr(strstr($request_uri, '&'), 4);

        echo "List of payments";
		$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $paymentList = Controller::find($tdb, 'payment');
		$user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
		$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $profile['firmid']);
        $len = count($paymentList);
        echo $len;
        
		print_r($paymentList);
    ?>
	<?php if($len < 1): ?>
        <p>There are no payments in the platform.</p>
    <?php endif ?>
    <?php if($len > 0): ?>
        <?php foreach ($paymentList as $key => $value): ?>
			<?php $bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[1]); ?>
			<?php $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[2]); ?>
			<?php $contract = Controller::findOne($tdb->getDbserver(), 'contract', 'coid', $value[3]); ?>
            <p>About prepared transaction :
			<br>
			<p>Bank Information : <?php echo $bank['name'] ?>, <?php echo $bank['city'] ?>, <?php echo $bank['country'] ?>, <?php echo $bank['phone'] ?> </p>
			<p>Law Information : <?php echo $firm['name'] ?>, <?php echo $firm['city'] ?>, <?php echo $firm['country'] ?>, <?php echo $firm['phone'] ?> </p>
			<p>Amount : <?php echo $contract['amount'] ?> </p>
			<a href=<?php echo "payment.php?user=$username&id=$value[0]" ?>>Details</a></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>