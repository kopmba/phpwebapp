<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


?>
<div>
    <?php 

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
		$bankid = substr(strstr($request_uri, '€'), 1);
        $lawid = substr(strstr($request_uri, 'µ'), 1);
		echo "$id $bankid $lawid";
        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $userid);

        $contract = Controller::findOne($tdb->getDbserver(), 'contract', 'coid', $id);
		$bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $bankid);
		$law = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $lawid);
		
    ?>

    <p>Do you want to create a payment for this contract ? </p>
    <form method="post" action=<?php echo "helper/create.php?user=$userid&id=$id" ?>>
        <input type="text" name="contract" hidden value=<?php echo $id ?>>
        <input type="text" name="bank" hidden value=<?php echo $bankid ?>>
		<input type="text" name="lawfirm" hidden value=<?php echo $lawid ?>>
        <input type="submit" value="Yes"/>
        <input type="button" value="Cancel"/>


    </form>
</div>