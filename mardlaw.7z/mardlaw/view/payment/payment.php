<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"]; 
        $id = substr(strstr($request_uri, '&'), 4);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        $payment = Controller::findOne($tdb->getDbserver(), 'payment', 'payid', $id);
		$bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment['bankid']);
		$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment['lawfirmid']);
		$contract = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $payment['contractid']);
    ?>

    <div>
		<form method="post" action=<?php echo "helper/sign.php?user=$username&id=$id" ?>>
			<?php if($user['roleid'] == 2 && $contract[4] == 0 && $firm): ?>
				Would you want to sign the document?
				<input type="submit" value="Accepter et Signer">
			<?php endif ?>
			<?php if($user['roleid'] == 2 && $contract[4] != 0 && $firm): ?>
				<p>Document signed! Checked in <a href=<?php echo "redirect.php?link=mardlaw/view/certifieddocument/certifieddocument.php&user=$usernameµ$id=$" ?>>here</a> </p>
			<?php endif ?>
		</form>
    </div>
    
</div>