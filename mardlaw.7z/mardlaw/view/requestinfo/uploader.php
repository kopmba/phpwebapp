
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');

    echo '<pre>';
    $imgbp = $_FILES['imgbp'];
	$imgac = $_FILES['imgac'];

    print_r($imgbp);
	print_r($imgac);

    fileupload();
	
	function fileupload() {
		
		postupload('imgbp', 'businessplanurl');
		postupload('imgac', 'accountdocurl');
		
		$request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $uri = 'Location: http://localhost/xampp/shop/view/package/list.php?user=';
        $url = "$uri$userid";
        header($url);
        exit;
		
	}
	
	function postupload($files, $property) {
		
		if(!empty($files)) {
			$img_desc = reArrayFiles($files);
			print_r($img_desc);
			foreach($img_desc as $val) {
				$newname = date('YmdHis', time()).rand().'.jpg';
				move_uploaded_file($val['tmp_name'],'./uploads/'.$newname);
			}
			$db = Util::getDb();
			$reid = $_POST['reid'];
			$requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $reid);
			$updated_requesterinfo = $requesterinfo;
			if($requesterinfo[property] == '') {
				$data = array("1" => $newname);
				$json = json_encode($data, true);
				$updated_product[property] = "$json";
			} else {
				$newimg = array("1" => $newname);
				$data = array_push(json_decode($requesterinfo[property], true), $newimg);
				$json = json_encode($data, true);
				$updated_product[property] = "$json";
			}
			Controller::update($db, 'requesterinfo', 'reid', $reid, $updated_product);

			
		}
		
		
	}

    function reArrayFiles($file) {
        $file_array = array();
        $file_count = count($file['name']);
        $file_key = array_keys($file);

        for($i=0;$i<$file_count;$i++) {
            foreach($file_key as $val) {
                $file_array[$i][$val] = $file[$val][$i];
            }
        }

        return $file_array;
    }

?>