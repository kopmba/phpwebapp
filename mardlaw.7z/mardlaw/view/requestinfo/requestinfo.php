<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];
        $id = substr(strstr($request_uri, '&'), 4);

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userId', $username);
        $user = Controller::findOne($db->getDbserver(), 'user', 'username', $username);
        
        $requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $id);
		$requester = Controller::findOne($db->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']);
		print_r($profile);
		echo $profile['firmid'];
		echo "==";
		echo $requesterinfo['validatorfirmid'];
		print_r($requesterinfo);
		print_r($user);
		
		//get the messagenotification
		$message = Controller::findOne($db->getDbserver(), 'messagenotification', 'requesterinfoid', $id);
	?>

    <div>
		<?php if($message['checked'] == 0): ?>
			<p style="background-color:gray">The requester : <?php echo $requester['fullname']; ?> &nbsp;&nbsp; 
			
			<?php if($user['roleid'] == 2 && $profile['firmid'] == $requesterinfo['validatorfirmid']): ?> 
				<a href=<?php echo "redirect.php?link=requestinfo/validate.php?user=$username&id=$requester[0]" ?>>Valider</a> | 
			<?php endif ?>	
			<a href=<?php echo "edit.php?user=$username&id=$requester[0]" ?>>Modifier</a>
			</p>
        <?php endif ?>
		<?php if($message['checked'] == 1): ?>
			<p>The requester : <?php echo $requester['fullname']; ?> &nbsp;&nbsp; 
			
			<?php if($user['roleid'] == 2 && $profile['firmid'] == $requesterinfo['validatorfirmid']): ?> 
				<a href=<?php echo "redirect.php?link=requestinfo/validate.php?user=$username&id=$requester[0]" ?>>Valider</a> | 
			<?php endif ?>	
			<a href=<?php echo "edit.php?user=$username&id=$requester[0]" ?>>Modifier</a>
			</p>
        <?php endif ?>
        <p>
            <?php if($user['roleid'] == 2 && $profile['firmid'] == $requesterinfo['setterfirmid']): ?>
                <a href=<?php echo "upload.php?user=$username&id=$requester[0]" ?>>Add documents</a> (Business plan | Account)
            <?php endif ?>
        </p>
    </div>
    
</div>