<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');


?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

        $id = substr(strstr($request_uri, '&'), 4);

        echo $id; 
        echo $userid;
        
        $requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $id);
        $firms = Controller::find($db, 'firm');
		$requester = Controller::findOne($db->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']);
        print_r($requesterinfo);
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="reid" hidden value=<?php echo $id ?>>         
        <input type="text" name="title" value=<?php echo $requesterinfo['title']?>>   
        <input type="text" name="setter" hidden  value=<?php echo $requesterinfo['setterfirmid'] ?>> 
		<textarea type="text" name="description"><?php echo $requesterinfo['description'] ?></textarea> 
        <div id="profile">
		   <h3>Requester Profile</h3>
		   <input type="text" name="username" hidden value=<?php echo $requester['firstname'] ?> >
		   <input type="text" name="username" hidden value=<?php echo $requester['lastname'] ?> >
		   <input type="text" name="address" value=<?php echo $requester['address'] ?> >
		   <input type="text" name="phone" value=<?php echo $requester['phone'] ?> >
		   <input type="text" name="city" value=<?php echo $requester['city'] ?> >
		   <input type="text" name="country" value=<?php echo $requester['country'] ?> >
		   <select name="gender">
				<option><?php echo $requester['gender'] ?></option>
				<option value="male">Male</option>
				<option value="female">Female</option>
		   </select>
		</div>
		<select name="validator">
			<?php $firmname = Controller::findOne($db->getDbserver(), 'firm', 'fid', $requesterinfo['validatorfirmid']); ?>
            <option><?php echo $firmname['name'] ?></option>
            <?php foreach ($firms as $key => $value): ?>
				<?php if($value[6] == 'Law'): ?>
					<option value=<?php echo $value[0] ?>><?php echo $value[1] ?> - <?php echo $value[2] ?></option>
				<?php endif ?>
            <?php endforeach ?>
        </select>
          
        
        <input type="submit" value="Update"/>

    </form>
</div>