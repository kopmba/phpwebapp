<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');

?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"]; 
        $id = substr(strstr($request_uri, '&'), 4);

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

		$requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $id);
		$requester = Controller::findOne($db->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']);
		
		$firms = Controller::find($db, 'firm');
		$signatures = Controller::find($db, 'signature');
		
	?>

    <p>Voulez vous valider ce document : <?php echo $requester['fullname'] ?></p>
    <form method="post" action=<?php echo "helper/validate.php?user=$username&id=$id" ?>>
		<input type="text" name="reid" hidden value=<?php echo $requesterinfo['reid'] ?>>
		<input type="text" name="validator" hidden value=<?php echo $requesterinfo['validatorfirmid'] ?>>
        <input type="text" name="fullname" hidden value=<?php echo $requester['fullname'] ?>>
		<input type="text" name="phone" hidden value=<?php echo $requester['phone'] ?>>
		<input type="text" name="country" hidden value=<?php echo $requester['country'] ?>>
		<input type="text" name="city" hidden value=<?php echo $requester['city'] ?>>
		<p>The validation required a bank to prepare the transaction!</p>
		<select name="bank">
            <option>--Choose a Bank--</option>
            <?php foreach ($firms as $key => $value): ?>
				<?php if($value[6] == 'Bank'): ?>
					<option value=<?php echo $value[0] ?>><?php echo $value[1] ?> - <?php echo $value[2] ?></option>
				<?php endif ?>
            <?php endforeach ?>
        </select>
		<p>The validation required a valid signature</p>
		<select name="signature">
            <option>--Choose your Signature--</option>
            <?php foreach ($signatures as $key => $value): ?>
				<?php $administrationinfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'adminfoid', $value[2]); ?>
				<?php $firm = Controller::findOne($db->getDbserver(), 'firm', 'fid', $value[1]); ?>
				<option value=<?php echo $value[0] ?>><?php echo $firm[1] ?> - <?php echo $administrationinfo[2] ?>,<?php echo $administrationinfo[3] ?></option>
            <?php endforeach ?>
        </select>
		<a class="button" href=<?php echo "list.php?user=$username" ?>>Annuler</a>
        <input type="submit" value="Valider"/>

    </form>
</div>