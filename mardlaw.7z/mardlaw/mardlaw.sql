-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 13 mai 2022 à 19:54
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mardlaw`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `edit_request_info` (OUT `requeststatus` VARCHAR(20), OUT `validator` MEDIUMINT(9), OUT `setter` MEDIUMINT(9))  NO SQL
BEGIN
set @msg = 'Message validé par : ' + validator;
IF requeststatus = 'current' THEN
update messagenotification set msg = @msg, checked = 1, edited = now() where firmidto = setter and firmidfrom = validator;
end if;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `administrationinfo`
--

CREATE TABLE `administrationinfo` (
  `admid` mediumint(9) NOT NULL,
  `publisherid` mediumint(9) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `docurl` varchar(200) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `administrationinfo`
--

INSERT INTO `administrationinfo` (`admid`, `publisherid`, `city`, `country`, `address`, `phone`, `description`, `docurl`, `created`, `edited`) VALUES
(1, 1, 'Bangui', 'RCA', '', NULL, 'dhgsfdsghfhdsjkfdskhfhskjdhkfdsf', NULL, '2022-05-10 19:16:08', '2022-05-10 19:16:08');

-- --------------------------------------------------------

--
-- Structure de la table `certifieddocument`
--

CREATE TABLE `certifieddocument` (
  `cdid` mediumint(9) NOT NULL,
  `paymentid` mediumint(9) NOT NULL,
  `lawfirmsignature` tinyint(1) NOT NULL,
  `banksignature` tinyint(1) NOT NULL,
  `docinfourl` varchar(200) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `certifieddocument`
--

INSERT INTO `certifieddocument` (`cdid`, `paymentid`, `lawfirmsignature`, `banksignature`, `docinfourl`, `created`, `edited`) VALUES
(1, 1, 1, 1, '', '2022-05-13 13:13:07', '2022-05-13 13:13:07');

-- --------------------------------------------------------

--
-- Structure de la table `contract`
--

CREATE TABLE `contract` (
  `coid` mediumint(9) NOT NULL,
  `requestinfoid` mediumint(9) NOT NULL,
  `bankid` mediumint(9) NOT NULL,
  `signatureid` mediumint(9) NOT NULL,
  `amount` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contract`
--

INSERT INTO `contract` (`coid`, `requestinfoid`, `bankid`, `signatureid`, `amount`, `created`, `edited`) VALUES
(1, 1, 2, 1, 0, '2022-05-10 20:22:41', '2022-05-10 20:22:41');

-- --------------------------------------------------------

--
-- Structure de la table `firm`
--

CREATE TABLE `firm` (
  `fid` mediumint(9) NOT NULL,
  `name` varchar(50) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `firmType` varchar(30) DEFAULT NULL,
  `imgUrl` varchar(200) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `firm`
--

INSERT INTO `firm` (`fid`, `name`, `city`, `country`, `phone`, `address`, `firmType`, `imgUrl`, `created`, `edited`) VALUES
(1, 'Law service investment', 'Bangui', 'RCA', NULL, NULL, 'Law', NULL, '2022-05-10 12:20:01', '2022-05-10 12:20:01'),
(2, 'Bank City', 'Libreville', 'Gabon', NULL, NULL, 'Bank', NULL, '2022-05-10 12:20:01', '2022-05-10 12:20:01'),
(3, 'Wazlaw', 'Douala', 'Cameroon', NULL, NULL, 'Law', NULL, '2022-05-10 12:27:07', '2022-05-10 12:27:07');

-- --------------------------------------------------------

--
-- Structure de la table `messagenotification`
--

CREATE TABLE `messagenotification` (
  `mnid` mediumint(9) NOT NULL,
  `firmidfrom` mediumint(9) NOT NULL,
  `firmidto` mediumint(9) NOT NULL,
  `requesterinfoid` int(9) DEFAULT NULL,
  `msg` text DEFAULT NULL,
  `checked` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `messagenotification`
--

INSERT INTO `messagenotification` (`mnid`, `firmidfrom`, `firmidto`, `requesterinfoid`, `msg`, `checked`, `created`, `edited`) VALUES
(1, 1, 3, 1, 'Validate a message!', 1, '2022-05-10 12:32:06', '2022-05-10 12:32:06'),
(2, 1, 3, 2, 'Validate a message!', 0, '2022-05-10 12:41:09', '2022-05-10 12:41:09'),
(3, 2, 1, 1, 'Please to checked the contract to be signed by you and the requester contact', 0, '2022-05-10 20:44:11', '2022-05-10 20:44:11'),
(4, 2, 1, 1, '', 0, '2022-05-10 20:36:07', '2022-05-10 20:36:07');

--
-- Déclencheurs `messagenotification`
--
DELIMITER $$
CREATE TRIGGER `prepare_payment_statement` AFTER INSERT ON `messagenotification` FOR EACH ROW BEGIN

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `payment`
--

CREATE TABLE `payment` (
  `payid` mediumint(9) NOT NULL,
  `bankid` mediumint(9) NOT NULL,
  `lawfirmid` mediumint(9) NOT NULL,
  `contractid` mediumint(9) NOT NULL,
  `terms_accepted` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `payment`
--

INSERT INTO `payment` (`payid`, `bankid`, `lawfirmid`, `contractid`, `terms_accepted`, `created`, `edited`) VALUES
(1, 2, 1, 1, 1, '2022-05-10 21:57:33', '2022-05-10 21:57:33');

--
-- Déclencheurs `payment`
--
DELIMITER $$
CREATE TRIGGER `create_certified_document` AFTER UPDATE ON `payment` FOR EACH ROW BEGIN
INSERT INTO `certifieddocument` (`cdid`, `paymentid`, `lawfirmsignature`, `banksignature`, `docinfourl`, `created`, `edited`) VALUES ('', new.payid, 0, 1, '', now(), now());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `proid` mediumint(9) NOT NULL,
  `firmid` mediumint(9) DEFAULT NULL,
  `firstname` varchar(80) NOT NULL,
  `lastname` varchar(80) NOT NULL,
  `fullname` varchar(80) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `userid` varchar(80) DEFAULT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `imgUrl` varchar(200) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `profile`
--

INSERT INTO `profile` (`proid`, `firmid`, `firstname`, `lastname`, `fullname`, `gender`, `userid`, `phone`, `city`, `country`, `imgUrl`, `address`, `created`, `edited`) VALUES
(1, 3, 'John', 'Doe', 'John Doe', 'male', 'admin', NULL, NULL, NULL, NULL, NULL, '2022-05-10 11:57:06', '2022-05-10 11:57:06'),
(2, NULL, 'Vincent', 'Janvier', 'Vincent Janvier', 'male', NULL, NULL, 'Bafoussam', 'Cameroon', NULL, NULL, '2022-05-10 12:29:16', '2022-05-10 12:29:16'),
(3, NULL, 'Nina', 'Johnson', 'Nina Johnson', 'female', NULL, NULL, 'Yaounde', 'Cameroon', NULL, NULL, '2022-05-10 12:29:16', '2022-05-10 12:29:16'),
(4, 1, 'Klara', 'Wolf', 'Klara Wolf', 'female', 'user1', '123456789', 'Bangui', 'RCA', NULL, NULL, '2022-05-13 14:52:10', '2022-05-13 14:52:10'),
(5, 2, 'Calvin', 'Obiang', 'Calvin Obiang', 'male', 'user2', '78984565', 'Libreville', 'Gabon', NULL, NULL, '2022-05-13 14:52:10', '2022-05-13 14:52:10');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `profile_client`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `profile_client` (
`email` varchar(80)
,`proid` mediumint(9)
,`firmid` mediumint(9)
,`firstname` varchar(80)
,`lastname` varchar(80)
,`fullname` varchar(80)
,`gender` varchar(20)
,`userid` varchar(80)
,`phone` decimal(10,0)
,`city` varchar(50)
,`country` varchar(40)
,`imgUrl` varchar(200)
,`address` varchar(40)
,`created` timestamp
,`edited` timestamp
,`role_name` varchar(20)
,`name` varchar(50)
,`firmType` varchar(30)
,`fcity` varchar(50)
,`fcountry` varchar(40)
,`fphone` decimal(10,0)
,`faddress` varchar(40)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `profile_dashboard`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `profile_dashboard` (
`email` varchar(80)
,`proid` mediumint(9)
,`firmid` mediumint(9)
,`firstname` varchar(80)
,`lastname` varchar(80)
,`fullname` varchar(80)
,`gender` varchar(20)
,`userid` varchar(80)
,`phone` decimal(10,0)
,`city` varchar(50)
,`country` varchar(40)
,`imgUrl` varchar(200)
,`address` varchar(40)
,`created` timestamp
,`edited` timestamp
,`role_name` varchar(20)
,`name` varchar(50)
,`firmType` varchar(30)
,`fcity` varchar(50)
,`fcountry` varchar(40)
,`fphone` decimal(10,0)
,`faddress` varchar(40)
);

-- --------------------------------------------------------

--
-- Structure de la table `requesterinfo`
--

CREATE TABLE `requesterinfo` (
  `reid` mediumint(9) NOT NULL,
  `setterfirmid` mediumint(9) NOT NULL,
  `validatorfirmid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) DEFAULT NULL,
  `requesterid` mediumint(9) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `requeststatus` varchar(20) DEFAULT NULL,
  `businessplanurl` varchar(200) DEFAULT NULL,
  `accountdocurl` varchar(200) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `requesterinfo`
--

INSERT INTO `requesterinfo` (`reid`, `setterfirmid`, `validatorfirmid`, `profileid`, `requesterid`, `title`, `description`, `requeststatus`, `businessplanurl`, `accountdocurl`, `created`, `edited`) VALUES
(1, 1, 3, 1, 2, 'Consulting Startuper', 'Provide software for companies', 'open', NULL, NULL, '2022-05-10 12:30:39', '2022-05-10 12:30:39'),
(2, 1, 3, 1, 3, 'Tech Startuper', 'Provide software to improve the sell of companies.', 'open', NULL, NULL, '2022-05-10 12:33:19', '2022-05-10 12:33:19');

--
-- Déclencheurs `requesterinfo`
--
DELIMITER $$
CREATE TRIGGER `create_message` AFTER INSERT ON `requesterinfo` FOR EACH ROW BEGIN
INSERT INTO `messagenotification` (`mnid`, `firmidfrom`, `firmidto`, `requesterinfoid`, `msg`, `checked`, `created`, `edited`) VALUES ('', new.setterfirmid, new.validatorfirmid, new.reid, 'Validate a message!', 0, now(), now());
end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `edit_message` AFTER UPDATE ON `requesterinfo` FOR EACH ROW BEGIN
Call edit_request_info(new.requeststatus, new.validatorfirmid, new.setterfirmid);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` mediumint(9) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id`, `role_name`, `description`, `created`, `edited`) VALUES
(1, 'admin', 'User allowed to updated all the contents', '2020-09-07 09:17:42', NULL),
(2, 'user', 'User allowed to update specific contnets', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `signature`
--

CREATE TABLE `signature` (
  `sigid` mediumint(9) NOT NULL,
  `firmid` mediumint(9) NOT NULL,
  `adminfoid` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `signature`
--

INSERT INTO `signature` (`sigid`, `firmid`, `adminfoid`, `created`, `edited`) VALUES
(1, 3, 1, '2022-05-10 19:49:33', '2022-05-10 19:49:33');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL,
  `token` varchar(20) DEFAULT NULL,
  `roleid` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `email`, `password`, `token`, `roleid`, `created`, `edited`) VALUES
('admin', 'admin@mardlaw.org', 'admin', NULL, 1, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user1', 'user1@mardlaw.org', '123456', '', 2, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user2', 'user2@mardlaw.org', 'user', NULL, 2, '2022-05-13 13:56:13', '2022-05-13 13:56:13');

-- --------------------------------------------------------

--
-- Structure de la vue `profile_client`
--
DROP TABLE IF EXISTS `profile_client`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `profile_client`  AS  select `profile_dashboard`.`email` AS `email`,`profile_dashboard`.`proid` AS `proid`,`profile_dashboard`.`firmid` AS `firmid`,`profile_dashboard`.`firstname` AS `firstname`,`profile_dashboard`.`lastname` AS `lastname`,`profile_dashboard`.`fullname` AS `fullname`,`profile_dashboard`.`gender` AS `gender`,`profile_dashboard`.`userid` AS `userid`,`profile_dashboard`.`phone` AS `phone`,`profile_dashboard`.`city` AS `city`,`profile_dashboard`.`country` AS `country`,`profile_dashboard`.`imgUrl` AS `imgUrl`,`profile_dashboard`.`address` AS `address`,`profile_dashboard`.`created` AS `created`,`profile_dashboard`.`edited` AS `edited`,`profile_dashboard`.`role_name` AS `role_name`,`profile_dashboard`.`name` AS `name`,`profile_dashboard`.`firmType` AS `firmType`,`profile_dashboard`.`fcity` AS `fcity`,`profile_dashboard`.`fcountry` AS `fcountry`,`profile_dashboard`.`fphone` AS `fphone`,`profile_dashboard`.`faddress` AS `faddress` from `profile_dashboard` where `profile_dashboard`.`role_name` <> 'admin' ;

-- --------------------------------------------------------

--
-- Structure de la vue `profile_dashboard`
--
DROP TABLE IF EXISTS `profile_dashboard`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `profile_dashboard`  AS  select `user`.`email` AS `email`,`profile`.`proid` AS `proid`,`profile`.`firmid` AS `firmid`,`profile`.`firstname` AS `firstname`,`profile`.`lastname` AS `lastname`,`profile`.`fullname` AS `fullname`,`profile`.`gender` AS `gender`,`profile`.`userid` AS `userid`,`profile`.`phone` AS `phone`,`profile`.`city` AS `city`,`profile`.`country` AS `country`,`profile`.`imgUrl` AS `imgUrl`,`profile`.`address` AS `address`,`profile`.`created` AS `created`,`profile`.`edited` AS `edited`,`role`.`role_name` AS `role_name`,`firm`.`name` AS `name`,`firm`.`firmType` AS `firmType`,`firm`.`city` AS `fcity`,`firm`.`country` AS `fcountry`,`firm`.`phone` AS `fphone`,`firm`.`address` AS `faddress` from (((`user` left join `profile` on(`profile`.`userid` = `user`.`username`)) left join `role` on(`user`.`roleid` = `role`.`id`)) left join `firm` on(`profile`.`firmid` = `firm`.`fid`)) ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `administrationinfo`
--
ALTER TABLE `administrationinfo`
  ADD PRIMARY KEY (`admid`),
  ADD KEY `publisher` (`publisherid`);

--
-- Index pour la table `certifieddocument`
--
ALTER TABLE `certifieddocument`
  ADD PRIMARY KEY (`cdid`),
  ADD KEY `paymentk` (`paymentid`);

--
-- Index pour la table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`coid`),
  ADD KEY `requestinfok` (`requestinfoid`),
  ADD KEY `bank` (`bankid`),
  ADD KEY `signature` (`signatureid`);

--
-- Index pour la table `firm`
--
ALTER TABLE `firm`
  ADD PRIMARY KEY (`fid`);

--
-- Index pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  ADD PRIMARY KEY (`mnid`),
  ADD KEY `fromfirm` (`firmidfrom`),
  ADD KEY `tofirm` (`firmidto`);

--
-- Index pour la table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payid`),
  ADD KEY `bankf` (`bankid`),
  ADD KEY `lawfirm` (`lawfirmid`),
  ADD KEY `contractk` (`contractid`);

--
-- Index pour la table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`proid`),
  ADD KEY `firmk` (`firmid`),
  ADD KEY `useridk` (`userid`);

--
-- Index pour la table `requesterinfo`
--
ALTER TABLE `requesterinfo`
  ADD PRIMARY KEY (`reid`),
  ADD KEY `setterfirmid` (`setterfirmid`),
  ADD KEY `validatorfirmid` (`validatorfirmid`),
  ADD KEY `profileid` (`profileid`),
  ADD KEY `requesterk` (`requesterid`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `signature`
--
ALTER TABLE `signature`
  ADD PRIMARY KEY (`sigid`),
  ADD KEY `firmid` (`firmid`),
  ADD KEY `adminfofk` (`adminfoid`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role` (`roleid`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrationinfo`
--
ALTER TABLE `administrationinfo`
  MODIFY `admid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `certifieddocument`
--
ALTER TABLE `certifieddocument`
  MODIFY `cdid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `contract`
--
ALTER TABLE `contract`
  MODIFY `coid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `firm`
--
ALTER TABLE `firm`
  MODIFY `fid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  MODIFY `mnid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `payment`
--
ALTER TABLE `payment`
  MODIFY `payid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `profile`
--
ALTER TABLE `profile`
  MODIFY `proid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `requesterinfo`
--
ALTER TABLE `requesterinfo`
  MODIFY `reid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `signature`
--
ALTER TABLE `signature`
  MODIFY `sigid` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `administrationinfo`
--
ALTER TABLE `administrationinfo`
  ADD CONSTRAINT `publisher` FOREIGN KEY (`publisherid`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `certifieddocument`
--
ALTER TABLE `certifieddocument`
  ADD CONSTRAINT `paymentk` FOREIGN KEY (`paymentid`) REFERENCES `payment` (`payid`);

--
-- Contraintes pour la table `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `bank` FOREIGN KEY (`bankid`) REFERENCES `firm` (`fid`),
  ADD CONSTRAINT `requestinfok` FOREIGN KEY (`requestinfoid`) REFERENCES `requesterinfo` (`reid`),
  ADD CONSTRAINT `signature` FOREIGN KEY (`signatureid`) REFERENCES `signature` (`sigid`);

--
-- Contraintes pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  ADD CONSTRAINT `fromfirm` FOREIGN KEY (`firmidfrom`) REFERENCES `firm` (`fid`),
  ADD CONSTRAINT `tofirm` FOREIGN KEY (`firmidto`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `bankf` FOREIGN KEY (`bankid`) REFERENCES `firm` (`fid`),
  ADD CONSTRAINT `contractk` FOREIGN KEY (`contractid`) REFERENCES `contract` (`coid`),
  ADD CONSTRAINT `lawfirm` FOREIGN KEY (`lawfirmid`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `firmk` FOREIGN KEY (`firmid`) REFERENCES `firm` (`fid`),
  ADD CONSTRAINT `useridk` FOREIGN KEY (`userid`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `requesterinfo`
--
ALTER TABLE `requesterinfo`
  ADD CONSTRAINT `profilek` FOREIGN KEY (`profileid`) REFERENCES `profile` (`proid`),
  ADD CONSTRAINT `requesterk` FOREIGN KEY (`requesterid`) REFERENCES `profile` (`proid`),
  ADD CONSTRAINT `setter` FOREIGN KEY (`setterfirmid`) REFERENCES `firm` (`fid`),
  ADD CONSTRAINT `validator` FOREIGN KEY (`validatorfirmid`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `signature`
--
ALTER TABLE `signature`
  ADD CONSTRAINT `adminfofk` FOREIGN KEY (`adminfoid`) REFERENCES `administrationinfo` (`admid`),
  ADD CONSTRAINT `firmfk` FOREIGN KEY (`firmid`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `role` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
