<!DOCTYPE html>
<html>
      <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Forgot password message</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="all,follow">
      </head>

      <body class="text-center">
		
        <form class="form-signin" action="dashboard/dashboard.php" method="POST">
	 <h3 style ="color:blue;">Password recovered successfully!</h1>
         <p  style="color:green;" class="mb-3 font-weight-normal">You received a new password : 123456</p>
         <p>Connect to your account and set your password!</p>
         <br><br>
         <a href="login.php" style="color:green" class="btn btn-lg btn-light btn-block" type="button">Login</a>
        </form>
      </body>
 </html>
  
