<?php

     //require("Dbconfig.php");
     //require("controller.php");
     //require("util/util.php");

     class ProfileController extends Controller {

			public static function updateProfile() {
				//get db server
				$db = Util::getDb();
				
				$username = $_POST['username'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);
				$user = Controller::findOne($db->getDbserver(), 'user', 'username', $username);
				
				$fname = $_POST['firstname'];
				$lname = $_POST['lastname'];					
				$fullname = "$fname $lname";
					
				//$uri = $_SERVER['REQUEST_URI'];
				//$img = Controller::upload();
				//print_r($img);
				
				$date_profile = new DateTime();
				$new_profile = $profile;
				$user['email'] = $_POST['email'];
				$new_profile['firstname'] = $_POST['firstname'];
				$new_profile['lastname'] = $_POST['lastname'];
				$new_profile['fullname'] = "$fname $lname";
				$new_profile['phone'] = $_POST['phone'];
				$new_profile['gender'] = $_POST['gender'];
				$new_profile['city'] = $_POST['city'];
				$new_profile['address'] = $_POST['address'];
				$new_profile['country'] = $_POST['country'];
				$new_profile['edited'] = $date_profile->format('Y-m-d H:i:s');
				$new_profile['created'] = $date_profile->format('Y-m-d H:i:s');
										 
				Controller::update($db, 'profile', 'userid', $username, $new_profile);
				Controller::update($db, 'user', 'username', $username, $user);
				
				
			}
			
			public static function changePassword() {
				$db = Util::getDb();
				
				$username = $_POST['username'];
				$user = Controller::findOne($db->getDbserver(), 'user', 'username', $username);
				
				$password = $_POST['password'];
				$confirm_password = $_POST['confirm_password'];	

				$date_profile = new DateTime();				

				if($password == $confirm_password) {
					
					$user['password'] = $password;
					$user['edited'] = $date_profile->format('Y-m-d H:i:s');
					Controller::update($db, 'user', 'userid', $username, $user);
					
				}
				
			}

     }

?>
