<?php

     class ProductController extends Controller {

            public static function uploadProduct() {
                    
            }

			public static function createProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$cname = $_POST['category'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'caid', $cname);
				
				$date_created = new DateTime();
				
				$product = array();
				$product['brand'] = $_POST['brand'];
				$product['pname'] = $_POST['pname'];
				$product['category'] = $category['caid'];
				$product['subcategory'] = $_POST['subcategory'];
				$product['description'] = $_POST['description'];
				$product['price'] = $_POST['price'];
				$product['year'] = $_POST['year'];
				$product['qty'] = $_POST['qty'];
				$product['imgs'] = '';
				$product['createdBy'] = $_POST['createdBy'];
				$product['created'] = $date_created->format('Y-m-d H:i:s');
				$product['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'product', 'pid', $product);

			}

			public static function updateProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$pid = $_POST['pid'];
				$product = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid);

				$cname = $_POST['category'];
				$category = Controller::findOne($db->getDbserver(), 'category', 'name', $cname);
				
				$date_created = new DateTime();
				
				$updated_product = $product;
				$updated_product['brand'] = $_POST['brand'];
				$updated_product['pname'] = $_POST['pname'];
				$updated_product['category'] = $category['caid'];
				$updated_product['subcategory'] = $_POST['subcategory'];
				$updated_product['description'] = $_POST['description'];
				$updated_product['price'] = $_POST['price'];
				$updated_product['year'] = $_POST['year'];
				$updated_product['qty'] = $_POST['qty'];
				$updated_product['edited'] = $date_created->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'product', 'pid', $pid, $updated_product);
				
            }
            
            public static function removeProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server
				$tdb = Util::getTDb();

				//$username = $_POST['userid'];

				$pid = $_POST['pid'];
				$product = Controller::findOne($db->getDbserver(), 'product', 'pid', $pid);
					 
				Controller::delete($db->getDbserver(), 'product', 'pid', $pid);
			}

     }

?>
