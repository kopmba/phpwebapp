<?php

     class PaymentController extends Controller {

			public static function createPayment() {
				//get db server
				$db = Util::getDb();

				//$username = $_POST['userid'];
				//$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

				$date_created = new DateTime();
				
				$payment = array();
				$payment['bankid'] = $_POST['bank'];
				$payment['contractid'] = $_POST['contract'];
				$payment['lawfirmid'] = $_POST['lawfirm'];
				$payment['terms_accepted'] = 0;
				$payment['created'] = $date_created->format('Y-m-d H:i:s');
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'payment', 'payid', $payment);
			}
			
			public static function accept_term() {
				
				//get db server
				$db = Util::getDb();

				$date_created = new DateTime();
				
				$id = $_POST['id'];
				$payment = Controller::findOne($tdb->getDbserver(), 'payment', 'payid', $id);
				
				$payment[4] = 1;
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::update($db, 'payment', 'payid', $id, $payment);
			}
     }

?>
