<?php
     class RequesterInfoController extends Controller {


			public static function createRequesterInfo() {
				//get db server
				$db = Util::getDb();

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userId', $username);

				$title = $_POST['title'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$requesterinfo = array();
				$requesterinfo['title'] = $title;
				$requesterinfo['description'] = $description;
				$requesterinfo['requeststatus'] = 'open';
				$requesterinfo['profileid'] = $profile['proid'];
				$requesterinfo['validatorfirmid'] = $_POST['validator'];
				$requesterinfo['setterfirmid'] = $_POST['setter'];
				$requesterinfo['created'] = $date_created->format('Y-m-d H:i:s');
				$requesterinfo['edited'] = $date_created->format('Y-m-d H:i:s');
				
				$fname = $_POST['firstname'];
				$lname = $_POST['lastname'];					
				$fullname = "$fname $lname";
				
				$requester = array();
				$requester['firstname'] = $_POST['firstname'];
				$requester['lastname'] = $_POST['lastname'];
				$requester['fullname'] = "$fname $lname";
				$requester['phone'] = $_POST['phone'];
				$requester['gender'] = $_POST['gender'];
				$requester['city'] = $_POST['city'];
				$requester['address'] = $_POST['address'];
				$requester['country'] = $_POST['country'];
				$requester['edited'] = $date_profile->format('Y-m-d H:i:s');
				$requester['created'] = $date_profile->format('Y-m-d H:i:s');

				Controller::save($db, 'profile', 'proid', $requester);
				Controller::save($db, 'requesterinfo', 'reid', $requesterinfo);

			}

			public static function updateRequesterInfo() {
				//get db server
				$db = Util::getDb();

				$reid = $_POST['reid'];
				$requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $reid);
				
				$requesterprofile = Controller::findOne($db->getDbserver(), 'profile', 'requesterid', $requesterinfo['requesterid']);

				$title = $_POST['title'];
				$description = $_POST['description'];
				
				$date_created = new DateTime();
				
				$updated_requesterinfo = $requesterinfo;
				$updated_requesterinfo['title'] = $title;
				$updated_requesterinfo['description'] = $description;
				$updated_requesterinfo['requeststatus'] = 'open';
				$updated_requesterinfo['validatorfirmid'] = $_POST['validator'];
				$updated_requesterinfo['setterfirmid'] = $_POST['setter'];
				$updated_requesterinfo['edited'] = $date_created->format('Y-m-d H:i:s');
				
				$requester = $requesterprofile;
				$requester['firstname'] = $_POST['firstname'];
				$requester['lastname'] = $_POST['lastname'];
				$requester['fullname'] = "$fname $lname";
				$requester['phone'] = $_POST['phone'];
				$requester['gender'] = $_POST['gender'];
				$requester['city'] = $_POST['city'];
				$requester['address'] = $_POST['address'];
				$requester['country'] = $_POST['country'];
				$requester['edited'] = $date_profile->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'updated_requesterinfo', 'reid', $reid, $updated_requesterinfo);
				Controller::update($db, 'requester', 'proid', $requesterprofile['proid'], $requester);
				
            }
			
			public static function validate() {
				$db = Util::getDb();

				$reid = $_POST['reid'];
				$requesterinfo = Controller::findOne($db->getDbserver(), 'requesterinfo', 'reid', $reid);
				$requesterinfo['requeststatus'] = 'current';
				
				$fullname = $_POST['fullname'];
				$phone = $_POST['phone'];
				$country = $_POST['country'];
				$city = $_POST['city'];
				$date_created = new DateTime();
				$prop = "$fullname - $country, $city, phone: $phone";
				
				$message = array();
				$message['firmidfrom'] = $_POST['bank'];
				$message['firmidto'] = $_POST['setter'];				
				$message['msg'] = "Please to provide the contract to be signed by a requester contact -> $prop!";
				$message['checked'] = 0;
				$message['requesterinfoid'] = $reid;
				$message['edited'] = $date_profile->format('Y-m-d H:i:s');
				$message['created'] = $date_profile->format('Y-m-d H:i:s');
				
				$contract = array();
				$contract['bankid'] = $_POST['bank'];
				$contract['requestinfoid'] = $reid;
				$contract['signatureid'] = $_POST['signature'];
				$contract['edited'] = $date_profile->format('Y-m-d H:i:s');
				$contract['created'] = $date_profile->format('Y-m-d H:i:s');

				Controller::save($db, 'contract', 'coid', $contract);
				Controller::update($db, 'requesterinfo', 'reid', $reid, $requesterinfo);
				Controller::save($db, 'messagenotification', 'mnid', $message);
				
			}

    }

?>
