<?php

     class AdministrationInfoController extends Controller {

            
			public static function createAdministrationInfo() {
				//get db server
				$db = Util::getDb();

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

				$date_created = new DateTime();
				
				$admininfo = array();
				$admininfo['phone'] = $_POST['phone'];
				$admininfo['publisherid'] = $profile['firmid'];
				$admininfo['description'] = $_POST['description'];
				$admininfo['city'] = $_POST['city'];
				$admininfo['address'] = $_POST['address'];
				$admininfo['country'] = $_POST['country'];
				$admininfo['edited'] = $date_profile->format('Y-m-d H:i:s');
				$admininfo['created'] = $date_profile->format('Y-m-d H:i:s');

				Controller::save($db, 'administrationinfo', 'admid', $admininfo);

			}

			public static function updateAdministrationInfo() {
				$db = Util::getDb();
				
				$id = $_POST['id'];
				$admininfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
				$date_created = new DateTime();
				
				$admininfo['phone'] = $_POST['phone'];
				$admininfo['publisherid'] = $profile['firmid'];
				$admininfo['description'] = $_POST['description'];
				$admininfo['city'] = $_POST['city'];
				$admininfo['address'] = $_POST['address'];
				$admininfo['country'] = $_POST['country'];
				$admininfo['edited'] = $date_profile->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'administrationinfo', 'admid', $id, $admininfo);
				
            }
            
            public static function sign() {
				//get db server
				$db = Util::getDb();

				$id = $_POST['id'];
				$admininfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
				$date_created = new DateTime();
				$firmid = $_POST['firmid'];
				$signature = array();
				$signature['adminfoid'] = $id;
				$signature['firmid'] = $firmid;				
				$signature['edited'] = $date_profile->format('Y-m-d H:i:s');
				$signature['created'] = $date_profile->format('Y-m-d H:i:s');
				Controller::save($db, 'signature', 'sigid', $signature);
			}
			
			public static function removeInfo() {
				//get db server
				$db = Util::getDb();

				//$username = $_POST['userid'];

				$id = $_POST['id'];
				$administrationinfo = Controller::findOne($db->getDbserver(), 'administrationinfo', 'admid', $id);
					 
				Controller::delete($db->getDbserver(), 'administrationinfo', 'admid', $id);
			}

    }

?>
