<?php

     class ContractController extends Controller {


			public static function createContract() {
				//get db server
				$db = Util::getDb();

				$username = $_POST['userid'];
				$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);

				$date_created = new DateTime();
				
				$contract = array();
				$contract['bankid'] = $_POST['bank'];
				$contract['requestinfoid'] = $_POST['reid'];
				$contract['signatureid'] = $_POST['signature'];
				$contract['edited'] = $date_profile->format('Y-m-d H:i:s');
				$contract['created'] = $date_profile->format('Y-m-d H:i:s');

				Controller::save($db, 'contract', 'coid', $contract);

			}

			public static function updateContract() {
				//get db server
				$db = Util::getDb();

				$id = $_POST['id'];
				$contract = Controller::findOne($db->getDbserver(), 'contract', 'coid', $id);
				
				$date_created = new DateTime();
				
				$contract['amount'] = $_POST['amount'];
				$contract['edited'] = $date_created->format('Y-m-d H:i:s');
				
				$requesterinfoid = Controller::findOne($db->getDbserver(), 'requesterinfoid', 'reid', $contract['requestinfoid']);
				$firm = Controller::findOne($db->getDbserver(), 'firm', 'fid', $contract['bankid']);
				$bankname = $firm['name'];
				
				$fullname = $_POST['fullname'];
				$phone = $_POST['phone'];
				$country = $_POST['country'];
				$city = $_POST['city'];
				$date_created = new DateTime();
				$prop = "$fullname - $country, $city, phone: $phone";
				
				$message = array();
				$message['firmidfrom'] = $contract['bankid'];
				$message['firmidto'] = $requesterinfoid['setterfirmid'];				
				$message['msg'] = "Please accept the terms of contract signed by the bank $bankname and a requester you could contact -> $prop!";
				$message['checked'] = 0;
				$message['requesterinfoid'] = $reid;
				$message['edited'] = $date_profile->format('Y-m-d H:i:s');
				$message['created'] = $date_profile->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'contract', 'coid', $id, $contract);
				Controller::save($db, 'messagenotification', 'mnid', $message);
            }
            

    }

?>
