<?php

    echo '<pre>';
    $img = $_FILES['img'];

    print_r($img);

    if(!empty($img)) {
        $img_desc = reArrayFiles($img);
        print_r($img_desc);

        foreach($img_desc as $val) {
            $newname = date('YmdHis', time()).mt.rand().'.jpg';
            move_uploaded_file($val['tmp_name'],'./uploads/'.$newname);
        }
    }

    function reArrayFiles($file) {
        $file_array = array();
        $file_count = count($file['name']);
        $file_key = array_keys($file);

        for($i=0;$i<$file_count;$i++) {
            foreach($file_key as $val) {
                $file_array[$i][$val] = $file[$val][$i];
            }
        }

        return $file_array;
    }

?>

