<?php

     class CartController extends Controller {

			public static function updateCart() {
				//get db server
				$db = Util::getDb();
				
				$date_created = new DateTime();
				$username = $_POST['userid'];
				$cart = Controller::findOne($db->getDbserver(), 'cart', 'userId', $username);
				
				if($cart) {
					$updated_cart = $cart;
					$cartid = $_POST['cartid'];
					$updated_cart['products'] = $_POST['products'];
					$updated_cart['edited'] = $date_created->format('Y-m-d H:i:s');

					Controller::update($db, 'cart', 'cartid', $cartid, $updated_cart);
				} else {
					$cart = array();
					$cart['userid'] = $username;
					$cart['products'] = $_POST['products'];
					$cart['created'] = $date_created->format('Y-m-d H:i:s');
					$cart['edited'] = $date_created->format('Y-m-d H:i:s');

					Controller::save($db, 'cart', 'cartid', $cart);
				}
				
				
			}

			public static function checkout() {
				//get db server
				$db = Util::getDb();

				$username = $_POST['userid'];
				$cart = Controller::findOne($db->getDbserver(), 'cart', 'userId', $username);

				$products = $cart['products'];

				return $products;
			}

     }

?>
