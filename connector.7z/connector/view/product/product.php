



<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>



<div id="container" class="container">
	 
	 <?php 
    
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6, 10);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($user);
        

        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
	//rint_r($product);
     ?>
	<menu>
        <a href=<?php echo "redirect.php?link=view/coupon/list.php&user=$username" ?>>Coupons</a> |
		<a href=<?php echo "redirect.php?link=view/message/list.php&user=$username" ?>>Messages</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "list.php?user=$username" ?>>Products</a> |	<a href=<?php echo "redirect.php?link=index.php" ?>>Logout</a>

      </menu>

      <hr>	
	<div>
        <p><h3>The product name : </h3> <?php echo $product['pname']; ?> &nbsp;&nbsp; <?php if($user['roleid'] ==2): ?> <a href=<?php echo "redirect.php?link=payment/create_product.php?user=$username&id=$product[0]" ?>>Acheter</a><?php endif ?> |<?php if($user['roleid'] ==1): ?> <a href=<?php echo "edit.php?user=$username&id=$product[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$product[0]" ?>>Supprimer</a><?php endif ?></p>
        
        <p>
            <?php if($user['roleid'] == 1): ?>
                <a href=<?php echo "upload.php?user=$username&id=$product[0]" ?>>Ajouter</a> (Images)
            <?php endif ?>
        </p>
    </div>
	
	<article>
        
        <section>
          <h3>Description</h3>
		  <p><?php echo $product['description'] ?></p>
          
        </section>
		<section>
            <img style="height:80px; width:80px;" src=<?php echo "http://localhost/xampp/connector/view/product/uploads/$product[8]" ?> />
		</section>
        <section>
          <h3>Product Information</h3>
		  <div>
              <ol class="list">
                <li>$<?php echo $product['price'] ?> USD #Price</li>
                <li><?php echo $product['year'] ?> #Year</li>
                <li><?php echo $product['qty'] ?> products #Available</li>
              </ol>
          </div>
		  <?php if($user['roleid'] == 2): ?>
			  <form method="post" action=<?php echo "helper/addtocart.php?user=$username" ?>>
					<input type="text" name="id" hidden value=<?php echo $product['pid'] ?>>
					<input type="text" name="userid" hidden value=<?php echo $user['proid'] ?>>
					
					<input type="submit" class="asphalt" value="Add To Cart">
			  </form>
		  <?php endif ?>
        </section>
      </article>
	  

</div>