

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
	require('../../template/gw/taglink.php');
    
?>


<?php 
	require('../../template/gw/header.php');
?>


<div id="container" class="container">
	 
	 <?php 
    
        session_start();
        $_SESSION["session"]='jdoe';
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        echo "List of products";

        $db = Util::getDb();
        $products = Controller::find($db, 'productpayedfromcart');

        $len = count($products);
        echo $len;
        
        if($id && $id >= 0) {
            $products = Controller::findOne($db->getDbserver(), 'productpayedfromcart', 'ppfcid', $id);
            $len = 1;
        }

    ?>

      <div class="padded">
        <div class="row">
          <div class="three fifths bounceInRight animated">
            <h1 id="title-list" class="zero museo-slab">Consulter les différents liens du Menu.</h1>
            <p id="entities" class="quicksand">Dashboard, Categories, Subcategories & Products</p>
          </div>
        </div>
      </div>
      <hr>
      <div class="align-right padded">
		<a href="" id="edit-profile" class="gap-right">Mon profil</a>
		<?php if($user['roleid'] == 1): ?>
        <a href="create.php" class="gap-right">Ajouter</a>
		<?php endif ?>
		<a href="" id="logout">Logout <i class="icon-signout"></i></a>
	  </div>
      <div class="align-right padded">
		<form action="#" method="get">
			<input id="search-category" name="search-category" type="text" placeholder="Rechercher">
		</form>
	  </div>
	  <div class="row">
        <aside class="one fifth padded bounceInLeft animated">
          <nav title="Shop by Category" role="menu" class="small-tablet nav vertical menu">
            <ul>
              <li class="one whole"><p id="category-list" style="color: white">Categories</p></li>
              <li class="one whole"><p id="subcategory-list">Sous-Categories</p></li>
              <li class="one whole"><p id="product-list">Produits</p></li>
            </ul>
          </nav>
        </aside>
        <article class="four fifths">
          <div class="row">
		    <?php if($user['roleid'] == 1): ?>
				<table id="table-view" class="responsive" data-max="25">
					<thead>
						<tr>
						  <th>Image</th>
						  <th>Name</th>
						  <th>Price ($)</th>
						</tr>
					</thead>
					<tbody>
					  <?php if($len > 1): ?>
						<?php foreach ($products as $key => $value): ?>
							<?php if($id == ''): ?>
								<?php $prod = Controller::findOne($db->getDbserver(), 'product', 'pid', $value[2]); ?>
								<?php $ownerid = $prod['ownerid']; ?>
								<?php $refcmd = $value[1]; ?>
								<tr>
								  <td style="height:80px; width:80px;"><?php  echo $value[6] ?></td>
								  <td><?php  echo $prod['pname'] ?></td>
								  <td><?php  echo $prod['amount'] ?></td>
								  <td><a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
								</tr>
							<?php endif ?>
							<?php if($id == ''): ?>
								<?php $prod = Controller::findOne($db->getDbserver(), 'product', 'pid', $value[2]); ?>
								<?php $ownerid = $prod['ownerid']; ?>
								<?php $refcmd = $value[1]; ?>
								<tr>
								  <td style="height:80px; width:80px;"><?php  echo $value[6] ?></td>
								  <td><?php  echo $prod['pname'] ?></td>
								  <td><?php  echo $prod['amount'] ?></td>
								  <td><a href=<?php echo "product.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
								</tr>
							<?php endif ?>
						<?php endforeach ?>
					  <?php endif ?>
						
					</tbody>
				</table>

			<?php endif ?>
            <div id="no-data" style="margin-left: 50%"></div>
          </div>
		  
        </article>
      </div>
	  
	  <?php 
	require('../../template/gw/footer.php');
?>
</div>