<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');
	
    $request_uri = $_SERVER['REQUEST_URI']; 
    $userid = substr(strstr($request_uri, '?'), 6);
	$id = substr(strstr($request_uri, '&'), 4);
	print_r($id);
	$db = Util::getDb();
	$shipping_edit = Controller::findOne($db->getDbserver(), 'shipping', 'cmdpayedid', $id);
	//print_r($shipping_edit);
	$transporter = $_POST['shipper'];
	//print_r($transporter);
	$shipping_edit['transporterid'] = $transporter;
	print_r($shipping_edit);
	Controller::update($db, 'shipping', 'shid', $shipping_edit[0], $shipping_edit);
	$payedid = $id; 
	$u = 'sportstore';
    
	$uri = 'Location: http://localhost/xampp/connector/view/comandpayed/order.php?user=';
    $url = "$uri$u&id=$payedid";
    header($url);
    exit;


    
?>