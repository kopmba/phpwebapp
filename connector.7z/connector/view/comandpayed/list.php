

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>




<div id="container" class="container">
	 
	 <?php 
    
       session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);

        echo "List of orders";

        $db = Util::getDb();
        $orders = Controller::find($db, 'commandpayed');

        $len = count($orders);
        echo $len;
        
        if($id && $id >= 0) {
            $order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $id);
            $len = 1;
        }

    ?>
	<?php if($user['roleid'] == 2): ?>
		<table id="table-view" class="responsive" data-max="25">
			<thead>
				<tr>
				  <th>Refcmd</th>
				  <th>Consumer</th>
				  <th>Producer</th>
				  <th>Connector</th>
				  <th>Amount ($)</th>
				  <th>Actions</th>
				</tr>
			</thead>
			<tbody>
			  <?php if($len >=1): ?>
				<?php foreach ($orders as $key => $value): ?>
					<?php if($id == ''): ?>
						<?php $consumer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[2]); ?>
						<?php $producer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[3]); ?>
						<?php $conector = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[4]); ?>
						<?php $shipping = Controller::findOne($db->getDbserver(), 'shipping', 'cmdpayedid', $order[0]); ?>
						
						<?php if($shipping[3] != 'REFUSED'): ?>
							<tr>
							  <td><?php  echo $value[1] ?></td>
							  <td><?php  echo $consumer['fullname'] ?></td>
							  <td><?php  echo $producer['fullname'] ?></td>
							  <td><?php  echo $conector['fullname'] ?></td>
							  <td><?php  echo $value[5] ?></td>
							  <td><a href=<?php echo "order.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
							</tr>
						<?php endif ?>
						
						<?php if($shipping[3] == 'REFUSED'): ?>
							<tr style="bacground-color: red;">
							  <td><?php  echo $value[1] ?></td>
							  <td><?php  echo $consumer['fullname'] ?></td>
							  <td><?php  echo $producer['fullname'] ?></td>
							  <td><?php  echo $conector['fullname'] ?></td>
							  <td><?php  echo $value[5] ?></td>
							  <td><a href=<?php echo "order.php?user=$username&id=$value[0]" ?>>View</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Edit</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Delete</a><?php endif ?></td>
							</tr>
						<?php endif ?>
					<?php endif ?>
				<?php endforeach ?>
			  <?php endif ?>
				
			</tbody>
		</table>
	<?php endif ?>
</div>