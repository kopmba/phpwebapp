<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');
    
?>

<div>
    <?php 
        session_start();
         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        
        $payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $id);
		$order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $payment[1]);
		$buyer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $order[2]);
    ?>
	
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>
	<hr>
    <div>
        <p>The payment for the order <b><?php echo $order[1]; ?></b>, done by <?php echo $buyer['fullname']; ?> </p>
    </div>
    
</div>