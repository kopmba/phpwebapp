<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


?>

<div>
    <?php 

        session_start();

         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];


        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);
       

        echo "List of commissions";

        //echo "List of payments";

        $db = Util::getDb();
        $commissions = Controller::find($db, 'commission');

        $len = count($commissions);
        echo $len;
        
        
       // print_r($payments);

    ?>
	
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>
	<hr>
    <?php if($len >= 1): ?>
        <?php foreach ($commissions as $key => $value): ?>
            <?php $order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $value[2]); ?>
			<table id="table-view" class="responsive" data-max="25">
				<thead>
					<tr>
					  <th>#</th>
					  <th>refcmd</th>
					  <th>amount($)</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo $value[0]; ?></td>
						<td><?php echo $order[1]; ?></td>
						<td><?php echo $value[3]; ?></td>
					</tr>
				</tbody>
			</table>
        <?php endforeach ?>
    <?php endif ?>
    
</div>