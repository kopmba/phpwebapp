<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 
    $id = substr(strstr($request_uri, '&'), 4);
    $userid = substr(strstr($request_uri,'&'), 6, 10);

    if (stristr($request_uri, 'product/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/view/product/list.php?user=';
        $param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'coupon/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/view/coupon/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'coupon/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/view/coupon/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'message/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/view/message/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'payment/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/view/payment/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	if (stristr($request_uri, 'comandpayed/list.php')==true){

        $uri = 'Location: http://localhost/xampp/connector/view/comandpayed/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	if (stristr($request_uri, 'product/cart.php')==true){

        $uri = 'Location: http://localhost/xampp/connector/view/product/cart.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'payment/list.php')==true){

        $uri = 'Location: http://localhost/xampp/connector/view/payment/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'shipping/list.php')==true){

        $uri = 'Location: http://localhost/xampp/connector/view/shipping/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	
	if (stristr($request_uri, 'transfer/list.php')==true){

        $uri = 'Location: http://localhost/xampp/connector/view/transfer/list.php?user=';
		$param = "$userid";
		$url = "$uri$param";
		header($url);
		exit;
    }
	if (stristr($request_uri, 'index.php') == true) {

        $uri = 'Location: http://localhost/xampp/connector/index.php';
		header($uri);
		exit;
    }
	
    else {

        echo "not found url";
    }
?>