<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');


?>

<div>
    <?php 
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];
		//print_r($username);
		
		$db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $userid);
		
		$user = Controller::findOne($db->getDbserver(), 'user', 'username', $userid);
		
        //print_r($profile);
    ?>
	
    <form method="post" action=<?php echo "helper/edit.php?user=$username" ?>>
        <input type="text" name="username" hidden value=<?php echo $username ?>>    
        <div id="profile">
		   <h3>Edit Profile</h3>
		   <input type="text" name="email" value=<?php echo $user['email'] ?> >
		   <input type="text" name="username" hidden value=<?php echo $profile['firstname'] ?> >
		   <input type="text" name="username" hidden value=<?php echo $profile['lastname'] ?> >
		   <input type="text" name="location" value=<?php echo $profile['location'] ?> >
		   <input type="text" name="phone" value=<?php echo $profile['phone'] ?> >
		   <input type="text" name="city" value=<?php echo $profile['city'] ?> >
		   <input type="text" name="country" value=<?php echo $profile['country'] ?> >
		   <select name="gender">
				<option><?php $profile['gender'] ?></option>
				<option value="male">Male</option>
				<option value="female">Female</option>
		   </select>
		</div>
		<br>
        <input type="submit" value="Update"/>

    </form>
</div>