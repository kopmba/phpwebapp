<?php
	
	$req_uri = $_SERVER['REQUEST_URI'];

	
	$param = substr(strstr($req_uri, '&'), 6); 

	if(stristr($_SERVER['REQUEST_URI'], 'profile/new.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/profile/new.php?user=';
		$url = "$uri$param";
		print_r($url);
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'profile/profile.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/profile/profile.php?user=';
		$url = "$uri$param";
		print_r($url);
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'profile/list.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/profile/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'issue/list.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'notation/list.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'profile/settings.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/profile/settings.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
?>
