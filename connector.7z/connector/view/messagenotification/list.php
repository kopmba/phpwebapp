

<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>




<div id="container" class="container">
	 
	 <?php 
    
        session_start();
		$request_uri = $_SERVER['REQUEST_URI']; 
		$userid = substr(strstr($request_uri, '?'), 6);
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $user = Controller::findOne($db->getDbserver(), 'profile_producer', 'username', $username);
        //print_r($profile);

        echo "List of messages";

        $db = Util::getDb();
        $messages = Controller::find($db, 'messagenotification');
		
        $len = count($messages);
        echo $len;
        

    ?>

      
      <hr>
      
	  
      <?php if($user['roleid'] == 1): ?>
		<?php if($len >= 1): ?>
			<?php foreach ($messages as $key => $value): ?>
			    <?php $order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $value[2]); ?>
				<?php if($value[4] == 0): ?>
					<p style="background-color: red;" class="message dismissible"><?php echo $value[3] ?> from command <a href=<?php echo "helper/viewstate.php?user=$username&id=$value[0]" ?>><?php echo $order[1]?></a></p>
				<?php endif ?>
				<?php if($value[4] == 1): ?>
					<p class="message dismissible"><?php echo $value[3] ?> from command <a href=<?php echo "redirect.php?link=view/comandpayed/order.php*user=$username&id=$value[2]" ?>><?php echo $order[1]?></a></p>
				<?php endif ?>
			<?php endforeach ?>
		  <?php endif ?>
	  <?php endif ?>
	  
	
</div>