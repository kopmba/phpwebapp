
<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>




<div id="container" class="container">
	 
	 <?php 
    
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        //print_r($user);

        if($user['roleid'] == '2') {
            $uri = 'Location: http://localhost/xampp/connector/view/dashboard/dashboard-client.php';
            $url = "$uri";
            header($url);
            exit;
        }
		
		if($user['roleid'] == '2') {
            $uri = 'Location: http://localhost/xampp/connector/view/dashboard/dashboard-client.php';
            $url = "$uri";
            header($url);
            exit;
        }
		
		if($user['roleid'] == '4') {
            $uri = 'Location: http://localhost/xampp/connector/view/dashboard/dashboard-connector.php';
            $url = "$uri";
            header($url);
            exit;
        }

    ?>
	<h1>Dashboard shipper</h1>
       <menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> 
    </menu>
	
	<hr>
	<article class="four fifths">
	  <div class="row">
		Welcome <?php echo $username ?> | <a href=<?php echo "redirect.php?link=view/profile/profile.php&user=$username" ?>>Settings</a>
		<div id="no-data" style="margin-left: 50%"></div>
	  </div>
	</article>
</div>