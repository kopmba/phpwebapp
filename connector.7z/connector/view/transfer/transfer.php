<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');
    
?>

<div>
    <?php 
        session_start();
         $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		$id = substr(strstr($request_uri, '&'), 4);
        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $user = Controller::findOne($tdb->getDbserver(), 'profile_producer', 'userId', $username);
        
        $transfer = Controller::findOne($db->getDbserver(), 'transfer', 'tid', $id);
		$payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $transfer[1]);
		$order = Controller::findOne($db->getDbserver(), 'commandpayed', 'cpid', $payment[1]);
		$producer = Controller::findOne($db->getDbserver(), 'profile', 'proid', $order[3]);
		$shipping = Controller::findOne($db->getDbserver(), 'shipping', 'cmdpayedid', $order[0]);
		$shipper = Controller::findOne($db->getDbserver(), 'profile', 'proid', $shipping[2]);
    ?>
	
	<menu>
		<a href=<?php echo "redirect.php?link=view/shipping/list.php&user=$username" ?>>Shippings</a> |
		<a href=<?php echo "redirect.php?link=view/payment/list.php&user=$username" ?>>Payments</a> |
		<a href=<?php echo "redirect.php?link=view/transfer/list.php&user=$username" ?>>Transfer</a> 
    </menu>
	<hr>
    <div>
        <p>Transfer done to <?php echo $producer['fullname'] ?> and <?php echo $shipper['fullname'] ?> </p>
    </div>
    
</div>