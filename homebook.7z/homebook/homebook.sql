-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 13 mai 2022 à 19:54
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `homebook`
--

-- --------------------------------------------------------

--
-- Structure de la table `hproductstatus`
--

CREATE TABLE `hproductstatus` (
  `hpsid` mediumint(9) NOT NULL,
  `hproductid` mediumint(9) NOT NULL,
  `bookerid` mediumint(9) NOT NULL,
  `bookingid` mediumint(9) NOT NULL,
  `pmonth` mediumint(9) NOT NULL,
  `pday` mediumint(9) NOT NULL,
  `pyear` mediumint(9) NOT NULL,
  `days` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Structure de la table `booking`
--

CREATE TABLE `booking` (
  `bid` mediumint(9) NOT NULL,
  `hproductid` mediumint(9) NOT NULL,
  `bookerid` mediumint(9) NOT NULL,
  `payid` mediumint(9) NOT NULL,
  `opname` varchar(50) NOT NULL,
  `fromday` varchar(50) DEFAULT NULL,
  `today` varchar(40) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `firmType` varchar(30) DEFAULT NULL,
  `imgUrl` varchar(200) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `messagenotification`
--

CREATE TABLE `messagenotification` (
  `mnid` mediumint(9) NOT NULL,
  `bookingid` mediumint(9) NOT NULL,
  `msg` text DEFAULT NULL,
  `checked` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `wsmessage`
--

CREATE TABLE `wsmessage` (
  `wsmid` mediumint(9) NOT NULL,
  `ownerid` mediumint(9) NOT NULL,
  `offerid` mediumint(9) NOT NULL,
  `msg` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `offer`
--

CREATE TABLE `offer` (
  `ofid` mediumint(9) NOT NULL,
  `hproductid` mediumint(9) NOT NULL,
  `rate` mediumint(9) NOT NULL,
  `startp` mediumint(9) NOT NULL,
  `endp` mediumint(9) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `proid` mediumint(9) NOT NULL,
  `firstname` varchar(80) NOT NULL,
  `lastname` varchar(80) NOT NULL,
  `fullname` varchar(80) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `userid` varchar(80) DEFAULT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `ptype` varchar(50) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `hproduct`
--

CREATE TABLE `hproduct` (
  `hpid` mediumint(9) NOT NULL,
  `ownerid` mediumint(9) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure de la table `hppics`
--

CREATE TABLE `hppics` (
  `hppid` mediumint(9) NOT NULL,
  `hproductid` mediumint(9) NOT NULL,
  `img1` varchar(50) DEFAULT NULL,
  `img2` varchar(40) DEFAULT NULL,
  `img3` varchar(40) DEFAULT NULL,
  `img4` varchar(50) DEFAULT NULL,
  `img5` varchar(40) DEFAULT NULL,
  `img6` varchar(40) DEFAULT NULL,
  `img7` varchar(50) DEFAULT NULL,
  `img8` varchar(40) DEFAULT NULL,
  `img9` varchar(40) DEFAULT NULL,
  `img10` varchar(40) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` mediumint(9) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id`, `role_name`, `description`, `created`, `edited`) VALUES
(1, 'admin', 'User allowed to updated all the contents', '2020-09-07 09:17:42', NULL),
(2, 'user', 'User allowed to update specific contnets', NULL, NULL);

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL,
  `token` varchar(20) DEFAULT NULL,
  `roleid` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `email`, `password`, `token`, `roleid`, `created`, `edited`) VALUES
('admin', 'admin@homebook.org', 'admin', NULL, 1, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user1', 'user1@homebook.org', '123456', '', 2, '2022-05-10 11:54:21', '2022-05-10 11:54:21'),
('user2', 'user2@homebook.org', 'user', NULL, 2, '2022-05-13 13:56:13', '2022-05-13 13:56:13');

-- --------------------------------------------------------

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `hppics`
--
ALTER TABLE `hppics`
  ADD PRIMARY KEY (`hppid`),
  ADD KEY `hproduct` (`hproductid`);

--
-- Index pour la table `hproduct`
--
ALTER TABLE `hproduct`
  ADD PRIMARY KEY (`hpid`),
  ADD KEY `owner` (`ownerid`);

--
-- Index pour la table `hproductstatus`
--
ALTER TABLE `hproductstatus`
  ADD PRIMARY KEY (`coid`),
  ADD KEY `hproductk` (`hproductid`),
  ADD KEY `booker` (`bookerid`),
  ADD KEY `booking` (`bookingid`);

--
-- Index pour la table `firm`
--
ALTER TABLE `wsmessage`
  ADD PRIMARY KEY (`wsmid`),
  ADD KEY `ownerk` (`ownerid`),
  ADD KEY `offerk` (`offerid`);

--
-- Index pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  ADD PRIMARY KEY (`mnid`),
  ADD KEY `bookingfk` (`bookingid`);

--
-- Index pour la table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `hproductfk` (`hproductid`),
  ADD KEY `bookerfk` (`bookerid`);

--
-- Index pour la table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`proid`),
  ADD KEY `useridk` (`userid`);

--
-- Index pour la table `requesterinfo`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`reid`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role` (`roleid`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `hproductstatus`
--
ALTER TABLE `hproductstatus`
  MODIFY `hpsid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `hppics`
--
ALTER TABLE `hppics`
  MODIFY `hppid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `hproduct`
--
ALTER TABLE `hproduct`
  MODIFY `hpid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `wsmessage`
--
ALTER TABLE `wsmessage`
  MODIFY `wsmid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  MODIFY `mnid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `offer`
--
ALTER TABLE `offer`
  MODIFY `ofid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `profile`
--
ALTER TABLE `profile`
  MODIFY `proid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `booking`
--
ALTER TABLE `booking`
  MODIFY `bid` mediumint(9) NOT NULL AUTO_INCREMENT;


--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `hproductstatus`
--
ALTER TABLE `hproductstatus`
  ADD CONSTRAINT `hproductk` FOREIGN KEY (`hproductid`) REFERENCES `hproduct` (`hpid`),
  ADD CONSTRAINT `booker` FOREIGN KEY (`bookerid`) REFERENCES `profile` (`proid`),
  ADD CONSTRAINT `booking` FOREIGN KEY (`bookingid`) REFERENCES `booking` (`bid`);

--
-- Contraintes pour la table `hppics`
--
ALTER TABLE `hppics`
  ADD CONSTRAINT `hproduct` FOREIGN KEY (`hproductid`) REFERENCES `hproduct` (`hpid`);

--
-- Contraintes pour la table `hproduct`
--
ALTER TABLE `hproduct`
  ADD CONSTRAINT `owner` FOREIGN KEY (`ownerid`) REFERENCES `profile` (`proid`);

--
-- Contraintes pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  ADD CONSTRAINT `bookingfk` FOREIGN KEY (`bookingid`) REFERENCES `booking` (`bid`);

--
-- Contraintes pour la table `wsmessage`
--
ALTER TABLE `wsmessage`
  ADD CONSTRAINT `ownerk` FOREIGN KEY (`ownerid`) REFERENCES `profile` (`proid`),
  ADD CONSTRAINT `offerk` FOREIGN KEY (`offerid`) REFERENCES `offer` (`ofid`);

--
-- Contraintes pour la table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `useridk` FOREIGN KEY (`userid`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `bookerfk` FOREIGN KEY (`bookerid`) REFERENCES `profile` (`proid`),
  ADD CONSTRAINT `hproductfk` FOREIGN KEY (`hproductid`) REFERENCES `hproduct` (`hpid`);

--
-- Contraintes pour la table `offer`
--
ALTER TABLE `offer`
  ADD CONSTRAINT `adminfofk` FOREIGN KEY (`adminfoid`) REFERENCES `administrationinfo` (`admid`),
  ADD CONSTRAINT `firmfk` FOREIGN KEY (`firmid`) REFERENCES `firm` (`fid`);

--
-- Contraintes pour la table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `role` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
