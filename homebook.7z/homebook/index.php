<?php 

    $url = 'Location: http://localhost/xampp/mardlaw/login.php';
    header($url);
    exit;

?>
  
