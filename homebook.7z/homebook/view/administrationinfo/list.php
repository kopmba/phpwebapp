<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/administrationinfo.php');


?>

<div>
    <?php 

        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];
		
        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);

        //print_r($profile);

        /*if($profile['role_name'] == 'admin') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-admin.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }*/
		

        $ainfoList = Controller::find($tdb, 'administrationinfo');

        $len = count($ainfoList);
        
    ?>
    <?php if($profile['role_name'] == 'user'): ?>
        <a href=<?php echo "create.php?user=$username" ?>>Add</a>
    <?php endif ?>
    <?php if($len < 1): ?>
        <p>There are no infos in the platform. Click on "Add" to add new one.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($ainfoList as $key => $value): ?>
            <p>About administration :<?php  echo $value[2] ?>, <?php  echo $value[3] ?>, <?php  echo $value[5] ?> &nbsp;&nbsp;
			<br>
			<p><?php  echo $value[6] ?></p>
			<a href=<?php echo "administrationinfo.php?user=$username&id=$value[0]" ?>>Voir</a> 
			<?php if($profile['role_name'] == 'user'): ?>|
				<a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a> |
				<a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Supprimer</a>
			<?php endif ?></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>