<?php
	
	$req_uri = $_SERVER['REQUEST_URI'];

	
	$userid = substr(strstr($req_uri, '&'), 6); 

	if(stristr($_SERVER['REQUEST_URI'], 'administrationinfo/list.php')) {
		$uri = 'Location: http://localhost/xampp/mardlaw/view/administrationinfo/list.php?user=';
		$url = "$uri$userid";
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'certifieddocument/list.php')) {
		$uri = 'Location: http://localhost/xampp/mardlaw/view/certifieddocument/list.php?user=';
		$url = "$uri$userid";
		header($url);
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'requesterinfo/list.php')) {
		$uri = 'Location: http://localhost/xampp/mardlaw/view/requesterinfo/list.php?user=';
		$url = "$uri$userid";
		header($url);
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'profile/settings.php')) {
		$uri = 'Location: http://localhost/xampp/mardlaw/view/profile/settings.php?user=';
		$url = "$uri$userid";
		header($url);
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'firms/list.php')) {
		$uri = 'Location: http://localhost/xampp/mardlaw/view/firms/list.php?user=';
		$url = "$uri$userid";
		header($url);
	} 
?>