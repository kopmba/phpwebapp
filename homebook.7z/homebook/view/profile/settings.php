<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');


?>

<div>
    <?php 
        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);
        
        //print_r($profile);
		
		//List of firms
        $db = Util::getDb();
        $firms = Controller::find($db, 'firm');

        //List of requesterinfos
        $requesterinfos = Controller::find($db, 'requesterinfo');

        //List of administrationinfos
        $administrationinfos = Controller::find($db, 'administrationinfo');

        //List of certifieddocuments
        $certifieddocuments = Controller::find($db, 'certifieddocument');

        
    ?>

    <form method="post" action=<?php echo "update.php?user=$username" ?>>
        <input type="text" name="username" hidden value=<?php echo $username ?>>    
        <div id="profile">
		   <h3>User Profile</h3>
		   <a href=<?php echo "settings_password.php?user=$username" ?>>Change Password</a>
		   <br><br>
		   <input type="text" name="email" value=<?php echo $profile['email'] ?> >
		   <input type="text" name="firstname" hidden value=<?php echo $profile['firstname'] ?> >
		   <input type="text" name="lastname" hidden value=<?php echo $profile['lastname'] ?> >
		   <input type="text" name="address" value=<?php echo $profile['address'] ?> >
		   <input type="text" name="phone" value=<?php echo $profile['phone'] ?> >
		   <input type="text" name="city" value=<?php echo $profile['city'] ?> >
		   <input type="text" name="country" value=<?php echo $profile['country'] ?> >
		   <select name="gender">
				<option><?php $profile['gender'] ?></option>
				<option value="male">Male</option>
				<option value="female">Female</option>
		   </select>
		</div>
        <input type="submit" value="Update"/>

    </form>
	
	<footer>
        <a href=<?php echo "redirect.php?link=view/administrationinfo/list.php&user=$username" ?>>Administrations</a> <?php echo count($administrationinfos); ?> |
		<a href=<?php echo "redirect.php?link=view/certifieddocument/list.php&user=$username" ?>>Certified Documents</a> <?php echo count($certifieddocuments); ?> |
		<a href=<?php echo "redirect.php?link=view/firm/list.php&user=$username" ?>>Firms</a> <?php echo count($firms); ?> |
		<a href=<?php echo "redirect.php?link=view/requestinfo/list.php&user=$username" ?>>RequestersInformation</a> <?php echo count($requesterinfos); ?>
    </footer>
</div>