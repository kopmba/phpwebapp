<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/package.php');
    
?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = null;
        $user = null;
        if($username && $username !== '') {
            $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);
            $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        }
        
        $db = Util::getDb();
        $package = Controller::findOne($db->getDbserver(), 'package', 'paid', $id);

        $products = json_decode($package['products'], true);

    ?>

    <div>
        <p>The package name : <?php echo $package['pname']; ?> 
            <?php if($profile !== ''): ?>
                <a href=<?php echo "redirect.php?link=payment/create_package.php?user=$username&id=$package[0]" ?>>Acheter</a>
            <?php endif ?>
            <?php if($profile == null): ?>
                <a href=<?php echo "redirect.php?link=together/index.php" ?>>Acheter</a>
            <?php endif ?>
            | <a href=<?php echo "edit.php?user=$username&id=$package[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$package[0]" ?>>Supprimer</a> </p>

        <p>
            Les produits :
            <ul>
                <?php foreach ($products as $key => $value): ?>
                    <?php 
                        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $value['id']);
                        $pid = $value['id'];
                    ?>
                    <li>nom : <a href=<?php echo "redirect.php?link=view/product/list.php&user=$username&id=$pid" ?>><?php  echo $product['pname'] ?></a> | qty :<?php  echo $value['qty'] ?></li>
                <?php endforeach ?> 
            </ul> 
        </p>

        <?php if($user['roleid'] == 1): ?>
            <a href=<?php echo "upload.php?user=$username&id=$package[0]" ?>>Ajouter</a> (Images)
        <?php endif ?>
        
    </div>
    
</div>