<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/firm.php');


?>
<div>
    <?php 
        session_start();
		$request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile_dashboard', 'userid', $username);

        //print_r($profile);

        if($profile['role_name'] == 'user') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-client.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }

    ?>

    <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
            
		<div id="profile">
		   <h3>Firm Info</h3>
		   <input type="text" name="name" placeholder="Firm name">
		   <input type="text" name="address" placeholder="Address">
		   <input type="text" name="phone" placeholder="Phone">
		   <input type="text" name="city" placeholder="City">
		   <input type="text" name="country" placeholder="Country">
			<select name="firmType">
				<option>--Firm type--</option>
				<option value="Law">Law</option>
				<option value="Bank">Bank</option>
		   </select>
		</div>
       
        <input type="submit" value="Add new"/>

    </form>
</div>