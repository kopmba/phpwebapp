<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 

    if (stristr($request_uri, 'category/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/category/list.php';
		$url = "$uri";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'category/edit.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/category/edit.php';
		$url = "$uri";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'category/create.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/category/create.php';
		$url = "$uri";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'category/delete.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/category/delete.php';
		$url = "$uri";
		header($url);
		exit;
    }

    if (stristr($request_uri, 'category/category.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/category/category.php';
		$url = "$uri";
		header($url);
		exit;
    }

    else {

        echo "not found url";
    }
?>