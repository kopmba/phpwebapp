<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');

    
?>

<div>
    <?php 
    
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        //print_r($profile);
        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        echo "List of categories";

        $db = Util::getDb();
        $categories = Controller::find($db, 'category');

        $len = count($categories);
        echo $len;
        
        if($id != '' && $id >= 0) {
            $categories = Controller::findOne($db->getDbserver(), 'category', 'caid', $id);
            $len = 1;
        }

    ?>
    <?php if($user['roleid'] == 1): ?>
        <a href="create.php">Ajouter</a>
    <?php endif ?>
    <?php if($len == 1): ?>
        <p>name :<?php  echo $value[1] ?> &nbsp;&nbsp; <a href=<?php echo "category.php?user=$username&id=$value[0]" ?>>Voir <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$id" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$id" ?>>Supprimer</a><?php endif ?></p>
    <?php endif ?>

    <?php if($len > 1): ?>
        <?php foreach ($categories as $key => $value): ?>
            <?php if($id == ''): ?>
                <p>name :<?php  echo $value[1] ?> &nbsp;&nbsp; <a href=<?php echo "category.php?user=$username&id=$value[0]" ?>>Voir <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Supprimer</a><?php endif ?></p>
            <?php endif ?>
            <?php if($id != ''): ?>
                <p>name :<?php  echo $value[1] ?> &nbsp;&nbsp; <a href=<?php echo "edit.php?user=$username&id=$id" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$id" ?>>Supprimer</a></p>
            <?php endif ?>
        <?php endforeach ?>
    <?php endif ?>
</div>