<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/contract.php');


?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();

        $id = substr(strstr($request_uri, '&'), 4);
		$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

        echo $id; 
        echo $userid;
        
        $contract = Controller::findOne($db->getDbserver(), 'contract', 'coid', $id);
        
    ?>

    <form method="post" action=<?php echo "helper/edit.php?user=$username&id=$id" ?>>
        <input type="text" name="id" hidden value=<?php echo $id ?>>         		
        <div id="contract">
		   <h3>Contract editing amount</h3>
		   <input type="text" name="amount" value=<?php echo $contract['amount'] ?> >
		</div>
          
        
        <input type="submit" value="Update"/>

    </form>
</div>