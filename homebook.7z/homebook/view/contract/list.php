<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/contract.php');


?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        echo "List of data";

        $contracts = Controller::find($tdb, 'contract');

        $len = count($contracts);
        
    ?>
    <?php if($len < 1): ?>
        <p>There are no contracts in the platform.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($contracts as $key => $value): ?>
			<?php $requesterinfo = Controller::findOne($tdb->getDbserver(), 'requesterinfo', 'reid', $value[1]); ?>
			<?php $bank = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[2]); ?>
			<?php $signature = Controller::findOne($tdb->getDbserver(), 'signature', 'sigid', $value[3]); ?>
			<?php $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $signature[1]); ?>
			<?php $requester = Controller::findOne($tdb->getDbserver(), 'profile', 'proid', $requesterinfo['requesterid']); ?>
            <p>About Contract :
			Contract specific for the directory<?php  echo $requester['fullname'] ?>, <?php  echo $requester['city'] ?>, <?php  echo $requester['country'] ?> &nbsp;&nbsp;
			<br>
			has been validated and signed by the firm <?php  echo $firm['name'] ?> from <?php  echo $firm['city'] ?>, <?php  echo $firm['country'] ?> the below date <?php  echo $signature['created'] ?>
			<a href=<?php echo "contract.php?user=$username&id=$value[0]" ?>>Voir</a> 
			<?php if($user['roleid'] == 1 && $bank): ?>|
				<a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a>
			<?php endif ?></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>