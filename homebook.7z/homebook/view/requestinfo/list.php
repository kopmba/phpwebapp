<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');


    echo 'product';
?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userId', $username);
        $user = Controller::findOne($db->getDbserver(), 'user', 'username', $username);

        echo "List of requesters information";

        $requesterList = Controller::find($db, 'requesterinfo');
		$info = array();

        $len = count($requesterList);
        print_r($requesterList);
		echo $len;
		

    ?>
    <?php if($user['roleid'] == 2): ?>
        <a href=<?php echo "create.php?user=$username" ?>>Add</a>
    <?php endif ?>
    <?php if($len < 1): ?>
        <p>There are no requesters in the platform. Click on "Add" to add new one.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($requesterList as $key => $value): ?>
			<?php $info = Controller::findOne($db->getDbserver(), 'profile', 'proid', $value[4]); ?>
            <p>Requester :<?php  echo $info['fullname'] ?> &nbsp;&nbsp; <a href=<?php echo "requestinfo.php?user=$username&id=$value[0]" ?>>Voir</a> <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$value[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$value[0]" ?>>Supprimer</a><?php endif ?></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>