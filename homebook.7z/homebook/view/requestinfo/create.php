<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/requestinfo.php');


?>
<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userId', $username);
	
		$firms = Controller::find($db, 'firm');
		
		echo "list of firms";
		echo count($firms);
    ?>

    <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
            
        <input type="text" name="title" placeholder="Title"> 
		<input type="text" name="setter" hidden value=<?php echo $profile['firmid'] ?>>
		<textarea type="text" name="description" placeholder="Description"></textarea>   
		<div id="profile">
		   <h3>Requester Profile</h3>
		   <input type="text" name="firstname" placeholder="Fistname">
		   <input type="text" name="lastname" placeholder="Lastname">
		   <input type="text" name="address" placeholder="Address">
		   <input type="text" name="phone" placeholder="Phone">
		   <input type="text" name="city" placeholder="City">
		   <input type="text" name="country" placeholder="Country">
		   <select name="gender">
				<option>--Gender--</option>
				<option value="male">Male</option>
				<option value="female">Female</option>
		   </select>
		</div>
        <select name="validator">
            <option>--Choose a Law validator--</option>
            <?php foreach ($firms as $key => $value): ?>
				<?php if($value[6] == 'Law'): ?>
					<option value=<?php echo $value[0] ?>><?php echo $value[1] ?> - <?php echo $value[2] ?></option>
				<?php endif ?>
            <?php endforeach ?>
        </select>
        
       
        <input type="submit" value="Add new"/>

    </form>
</div>