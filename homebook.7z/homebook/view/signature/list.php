<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/signature.php');


?>

<div>
    <?php 

        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        echo "List of signatures";

        $signatures = Controller::find($tdb, 'signature');

        $len = count($signatures);
        
    ?>
    <?php if($len < 1): ?>
        <p>There are no signatures in the platform. Click on "Add" to add new one.</p>
    <?php endif ?>

    <?php if($len > 0): ?>
        <?php foreach ($signatures as $key => $value): ?>
			<?php $firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $value[1]); ?>
            <p>Signed by : <?php  echo $firm['name'] ?> le <?php  echo $firm['created'] ?> &nbsp;&nbsp;
			<a href=<?php echo "signature.php?user=$username&id=$value[0]" ?>>Detail</a>
        <?php endforeach ?>
    <?php endif ?>
    
</div>