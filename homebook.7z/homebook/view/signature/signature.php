<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/signature.php');
    
?>

<div>
    <?php 
        session_start();
        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);
		
        $_SESSION["session"]=$userid;
        $username = $_SESSION["session"]; 
        $id = substr(strstr($request_uri, '&'), 4);

        $tdb = Util::getDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        
        $signature = Controller::findOne($tdb->getDbserver(), 'signature', 'sigid', $id);
		$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $signature['firmid']);
    ?>

    <div>
		<p>Signed by : <?php  echo $firm['name'] ?> le <?php  echo $firm['created'] ?> &nbsp;&nbsp;
		<a href=<?php echo "list.php?user=$username" ?>>List</a>
    </div>
    
</div>