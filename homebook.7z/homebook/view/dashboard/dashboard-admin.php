<?php

    require("../../../appcore/config/dbconfig.php");
	require("../../../appcore/controller/controller.php");
	require("../../../src/util/util.php");
	require('../../../src/controller/auth.php');

    
?>

<div>

    <?php

        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getDb();
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        //print_r($user);

        if($user['roleid'] == '2') {
            $uri = 'Location: http://localhost/xampp/mardlaw/view/dashboard/dashboard-client.php?user=';
            $url = "$uri$username";
            header($url);
            exit;
        }

        //List of firms
        $db = Util::getDb();
        $firms = Controller::find($db, 'firm');

        //List of requesterinfos
        $requesterinfos = Controller::find($db, 'requesterinfo');

        //List of administrationinfos
        $administrationinfos = Controller::find($db, 'administrationinfo');

        //List of certifieddocuments
        $certifieddocuments = Controller::find($db, 'certifieddocument');
		
		//List of contracts
		$contracts = Controller::find($db, 'contract');
		
		//List of signatures
		$signatures = Controller::find($db, 'signature');

        //List of messages
        $messages = Controller::find($db, 'messagenotification');

        //List of payments
        $payments = Controller::find($db, 'payment');

        //List of profiles
        $profiles = Controller::find($db, 'profile');

    ?>
	
	<menu>
        <a href=<?php echo "view/administrationinfo/list.php?user=$username" ?>>Administrations</a> <?php echo count($administrationinfos); ?> |
		<a href=<?php echo "view/certifieddocument/list.php?user=$username" ?>>Certified Documents</a> <?php echo count($certifieddocuments); ?> |
		<a href=<?php echo "view/contract/list.php?user=$username" ?>>Contracts</a> <?php echo count($contracts); ?> |
		<a href=<?php echo "view/firm/list.php?user=$username" ?>>Firms</a> <?php echo count($firms); ?> |
		<a href=<?php echo "view/messagenotification/list.php?user=$username" ?>>Messages</a> <?php echo count($messages); ?> |
		<a href=<?php echo "view/payment/list.php?user=$username" ?>>Payments</a> <?php echo count($payments); ?> |
		<a href=<?php echo "view/profile/list.php?user=$username" ?>>Profiles</a> <?php echo count($profiles); ?> |
		<a href=<?php echo "view/requestinfo/list.php?user=$username" ?>>RequestersInformation</a> <?php echo count($requesterinfos); ?> |
		<a href=<?php echo "view/role/list.php?user=$username" ?>>Roles</a> <?php echo count($roles); ?> |
		<a href=<?php echo "view/signature/list.php?user=$username" ?>>Signatures</a> <?php echo count($signatures); ?> |
		<a href=<?php echo "view/user/list.php?user=$username" ?>>Users</a> <?php echo count($users); ?>
    </menu>
	
	<p>Welcome <?php echo $username ?> ! </p> Click <a href=<?php echo "redirect.php?link=view/profile/settings.php&user=$username" ?>>here</a> to set your profile.
</div>