<?php

    
    require("../../../appcore/config/dbconfig.php");
	require("../../../appcore/controller/controller.php");
	require("../../../src/util/util.php");
	require('../../../src/controller/auth.php');

    session_start();

    $request_uri = $_SERVER['REQUEST_URI']; 
    $userid = substr(strstr($request_uri, '?'), 6);

    $_SESSION["session"]= $userid;
    $username = $_SESSION["session"];

    $tdb = Util::getTDb();
    $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

    print_r($user);

    if($user['roleid'] == '1') {
        $uri = 'Location: http://localhost/xampp/shop/view/dashboard/dashboard-admin.php';
		$url = "$uri";
		header($url);
		exit;
    } else {
        $uri = 'Location: http://localhost/xampp/shop/view/dashboard/dashboard-client.php';
		$url = "$uri";
		header($url);
		exit;
    }

    
?>