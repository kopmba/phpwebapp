<?php 

    require('appcore/config/dbconfig.php');
    require('appcore/controller/controller.php');
    require('src/util/util.php');
    require('src/controller/auth.php');


    AuthController::update_password_get();

    $url = 'Location: http://localhost/xampp/mardlaw/forget_password_message.php';
    header($url);
    exit;
    
?>