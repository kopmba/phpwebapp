<?php

     class CertifiedDocumentController extends Controller {

			public static function createCertifiedDocument() {
				//get db server
				$db = Util::getDb();

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);
				
				$date_created = new DateTime();
				
				$cdocument = array();
				$cdocument['paymentid'] = $_POST['paymentid'];
				$cdocument['banksignature'] = 0;
				$cdocument['lawfirmsignature'] = 0;
				$cdocument['created'] = $date_created->format('Y-m-d H:i:s');
				$cdocument['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'cdocument', 'cdid', $cdocument);

			}


    }

?>
