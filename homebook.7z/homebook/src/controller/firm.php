<?php

     class FirmController extends Controller {


			public static function createFirm() {
				//get db server
				$db = Util::getDb();
				
				$username = $_POST['userid'];
				$profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userid', $username);

				$date_created = new DateTime();
				
				$firm = array();
				$firm['name'] = $_POST['name'];
				$firm['country'] = $_POST['country'];
				$firm['city'] = $_POST['city'];
				$firm['address'] = $_POST['address'];
				$firm['phone'] = $_POST['phone'];
				$firm['firmtype'] = $_POST['firmtype'];
				$firm['created'] = $date_created->format('Y-m-d H:i:s');
				$firm['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'firm', 'fid', $firm);

			}

			public static function updateFirm() {
				//get db server
				$db = Util::getDb();

				//get db server
				$db = Util::getDb();
				
				$id = $_POST['id'];
				$firm = Controller::findOne($tdb->getDbserver(), 'firm', 'fid', $id);

				$date_created = new DateTime();
				
				$firm['name'] = $_POST['name'];
				$firm['country'] = $_POST['country'];
				$firm['city'] = $_POST['city'];
				$firm['address'] = $_POST['address'];
				$firm['phone'] = $_POST['phone'];
				$firm['firmtype'] = $_POST['firmtype'];
				$firm['edited'] = $date_created->format('Y-m-d H:i:s');
					 
				Controller::update($db, 'firm', 'fid', $id, $firm);
				
            }

    }

?>
