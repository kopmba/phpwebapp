<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}
    </style>
  </head>
  <?php 
  
	require("../appcore/config/dbconfig.php");
	require("../appcore/config/storage.php");
	require("../appcore/config/i18n.php");
	require("../appcore/auth/auth.php");
    	require("../appcore/controller/controller.php");
    	require("../src/util/util.php");
	require('../src/controller/auth.php');
	require('dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";
	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	
	
	if($profile['role'] != 'client_a') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  
  ?>
  <body>             
	<h2>Bienvenue sur TocTok</h2>
	<div>
		<h4>Bienvenue dans votre espace TocTok</h5>
	</div>
	<footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
