
<?php
	
	require("../appcore/config/dbconfig.php");
	require("../appcore/config/storage.php");
        require("../appcore/auth/auth.php");
        require("../appcore/controller/controller.php");
        require("../src/util/util.php");
	require('../src/controller/auth.php');
	
	$data = AuthController::login();
	print_r($data);
	if($data['profile']['role'] == "admin") {
		//print_r($data['profile']['role_name']);
		$username = $data['profile']['username'];
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard-admin.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	} else if($data['profile']['role'] == "client_a") {
		//print_r($data['profile']['role_name']);
		$username = $data['profile']['username'];
		print_r($username);
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard-client.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	} else if($data['profile']['role'] == "client_b") {
		$username = $data['profile']['username'];
		print_r($username);
		$uri = 'Location: http://localhost:8081/toctok/dashboard/_dashboard-client.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	} else {
		$username = $data['profile']['username'];
		print_r($username);
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard-mixte.php?user=';
		$url = "$uri$username";
	   header($url);
	   exit;
	}
	
	
?>
