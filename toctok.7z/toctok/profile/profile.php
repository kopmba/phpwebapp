<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}

		body {
            font-family: Arial, Helvetica, sans-serif;
        }

        h1 {
            color: #375e97;
            font-size: 2em;
            font-family: Georgia, 'Times New Roman', Times, serif;
            border-bottom: 1px solid #375e97;
        }

        h2 {
            font-size: 1.5em;
        }

        .category {
            color: #999999;
            font-weight: bold;
        }

        a:link, a:visited {
            color: #fb6542;
        }

        a:hover {
            text-decoration: none;
        }

    </style>
  </head>

  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
    require("../../appcore/controller/controller.php");
    require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	
	if($profile['role'] != 'admin') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}


  ?>
  <body>
    	<nav class="w-bgmf clearfix ">
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
	    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
		</nav>
		<div id="profile">
		   <h1><?php echo $fullname ?></h1>
		   <div class="title"><?php echo $username ?></div>
		   <p>Réside dans la ville de : <?php echo $data['profile']['city'] ?>, <?php echo $data['profile']['country'] ?></p>
		   <h2>Contact information</h2>
	        <ul>
	            <li>Adresse : <?php echo $data['profile']['address'] ?></li>
	            <li>Tel: <?php echo $data['profile']['phone'] ?></li>
	        </ul>
		</div>
    </form>
	<footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
