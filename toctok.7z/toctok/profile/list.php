<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}
    </style>
  </head>
  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
     	require("../../appcore/controller/controller.php");
     	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	$profiles = Controller::find(Util::getDb(), 'profile');

	if($profile['role'] != 'admin') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  ?>
  <body>
  	<nav class="w-bgmf clearfix ">
    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
    	<a class="nav-menu" href=<?php echo "profile/list.php&user=$username" ?>>Profils</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
	</nav>
    <h3>Les profils : <a href=<?php echo "new.php?user=$username" ?>>Ajouter</a></h3>
    <table class="w-body w-table w-shadow">
	  <thead>
        <tr>
		  <th class="w-table-cell">Nom complet</th>
		  <th class="w-table-cell">Nom d'utilisateur</th>
		  <th class="w-table-cell">Téléphone</th>
		  <th class="w-table-cell">Adresse</th>
		  <th class="w-table-cell">Ville</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($profiles as $key=>$value): ?>
        	<tr>
        	   <td class="title"><?php echo $value['1']; ?></td>
          		<td class="w-table-cell-label"><b class="w-table-cell-label">ID</b><?php echo $value['0']; ?></td>
          		<td><b class="w-table-cell-label">TEL</b><?php echo $value['4']; ?></td>
          		<td><b class="w-table-cell-label">ADRESSE</b><?php echo $value['5']; ?></td>
          		<td><b class="w-table-cell-label">VILLE</b><?php echo $value['6']; ?></td>
			    <td><a href=<?php echo "profile/profile.php?user=$username" ?>>Voir</a> | <a href=<?php echo "profile/settings.php?user=$username" ?>>Modifier</a>
        	</tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
