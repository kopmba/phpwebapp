<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}

    </style>
  </head>

  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
    require("../../appcore/controller/controller.php");
    require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	
	if($profile['role'] == 'guest') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}


  ?>
  <body>
  		<nav class="w-bgmf clearfix ">
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
	    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
		</nav>
    <form method="post" action=<?php echo "update.php?user=$username" ?>>
		<div id="profile">
		   <h3>User Profile</h3>
		   <input type="text" name="username" hidden value=<?php echo $data['profile']['username'] ?> >
			   <input type="text" name="fullname" placeholder="Nom complet" value=<?php echo $fullname ?> >
			   <input type="text" name="address" placeholder="Localisation" value=<?php echo $data['profile']['address'] ?> >
			   <input type="text" name="phone" placeholder="Telephone" value=<?php echo $data['profile']['phone'] ?> >
			   <input type="text" name="city" placeholder="Ville" value=<?php echo $data['profile']['city'] ?> >
			   <input type="text" name="country" placeholder="Pays" value=<?php echo $data['profile']['country'] ?> >
			   <select name="role">
					<option value=<?php echo $data['profile']['role'] ?>><?php echo $data['profile']['role'] ?></option>
					<option value="client_a">A</option>
					<option value="client_b">B</option>
					<option value="mixte">M</option>
			   </select>
		</div>
		<br><br>
		<input type="submit" value="Modifier"/>
    </form>
	<footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
