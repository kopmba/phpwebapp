<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	

		@media (min-width: 415px) {
			.nav-menu {
	    		text-decoration: none;
	    		margin: 0px;
	    	}

	    	nav {
			    display: block;
			}
	    	.menu-left {
			    margin-left: auto;
			}

			footer {
				margin-top: 278px;
			}

			input {
				width: 450px;
			}

			.w-grid, .w-grid-half {
				padding: 3px;
			}

			.w-btn-lg {
			    display: inline;
			    width: 30%;
			    margin-left: -950px;
			    margin-top: 148px;
			}
		}

		@media (max-width: 414px) {

			#menu {
				border: 1px solid black;
			}

			.nav-menu {
				display: none;
			}
			.nav-menu.menu {
				display: inherit;
				margin-left: -330px;
			}
			.w-btn-lg {
			    display: inline;
			    width: 100%;
			    margin-left: 2px;
			}

			footer {
				margin-top: 358px;
			}

			.w-row {
				margin-left: -4px;
			}

			.sidebar {
				list-style: none;
			}

			#container {
			    left: 0;
			    -webkit-transform: translate3d(0,0,0);
			    -moz-transform: translate3d(0,0,0);
			    transform: translate3d(0,0,0);

			    -webkit-transition: -webkit-transform 300ms ease;
			    -webkit-transition-duration: 300ms;
			    -moz-transition: -moz-transform 300ms ease;
			    transition: transform 300ms ease;
			}
		}

    </style>
  </head>
  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
     	require("../../appcore/controller/controller.php");
     	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$param = substr(strstr($req_uri, '?'), 6);
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	if($profile['role'] != 'admin') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  ?>
  <body>
  	<div id="container">
	  	<nav class="w-bgmf clearfix ">
	  		<a class="nav-menu menu-hamburger" href="#menu" onclick="push(this)">Menu</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
	    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
	    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
		</nav>

		
	    <form method="post" action=<?php echo "create.php?user=$username" ?>>
			<div id="profile">
			   <h3>Ajouter un profil</h3>
			   <div class="w-row">
			   	<div class="w-grid">
			   		<input type="text" name="fullname" placeholder="Nom complet" />
			   	</div>
			   </div>
			   <div class="w-row">
			   	<div class="w-grid-half">
			   		<input type="text" name="phone" placeholder="Telephone"  />	
			   	</div>
			   	<div class="w-grid-half">
			   		<select name="role">
						<option value="">--Rôle Type--</option>
						<option value="client_a">A</option>
						<option value="client_b">B</option>
						<option value="mixte">M</option>
				   </select>
			   	</div>
			   </div>
			   <div class="w-row">
			   	<div class="w-grid">
			   		<input type="text" name="address" placeholder="Localisation" />
			   	</div>
			   		
			   </div>
			   <div class="w-row">
			   	<div class="w-grid-half">
			   		<select name="country">
						<option value="">--Choisir le pays--</option>
						<option value="Cameroun">Cameroun</option>
						<option value="Congo">Congo</option>
						<option value="Gabon">Gabon</option>
						<option value="Guinée Equatoriale">Guinée Eq.</option>
						<option value="RCA">RCA</option>
						<option value="RDC">RDC</option>
						<option value="mixte">Tchad</option>
				   </select>
			   	</div>
			   	<div class="w-grid-half">
			   		<input type="text" name="city" placeholder="Ville"  />
			   	</div>
			   </div>			   
			</div>
			<input class="w-btn w-shadow w-btn-lg" type="submit" value="Creer"/>
	    </form>
		<footer class="w-bgmf clearfix">
			<p style="text-align: center">Copyright Mardets</p>
		</footer>
	</div>
	<div data-ui="panel" id="menu" class="w-panel w-panel-left w-panel-d-push w-panel-animate w-panel-open">
		<h3><?php echo $fullname ?></h3>
		<hr>
		<ul class="sidebar">
			<li><a href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
</li>
			<li><a href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a></li>
			<li><a href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a></li>
			<li><a href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a></li>
		</ul>

    </div>
  </body>
  <script>
        document.addEventListener('click', function(ev) {
        	let hash = '';
        	if(ev.target.hash) {
        		hash = ev.target.hash.substring(1);
        	}
            let id = hash;
            let panel = document.getElementById(id);
            let container = document.getElementById('container');
            if(id === 'menu') {
                panel.style.transform = 'translate3d(0,0,0)';
                container.style.transform = 'translate3d(17em,0,0)';
            } else {
            	panel = document.getElementById('menu');
            	panel.style.transform = 'translate3d(-17em,0,0)';
                container.style.transform = 'translate3d(0,0,0)';
            }
            
        });
  </script>
</html>
