<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}

		body {
            font-family: Arial, Helvetica, sans-serif;
        }

        h1 {
            color: #375e97;
            font-size: 2em;
            font-family: Georgia, 'Times New Roman', Times, serif;
            border-bottom: 1px solid #375e97;
        }

        h2 {
            font-size: 1.5em;
        }

        .category {
            color: #999999;
            font-weight: bold;
        }

        a:link, a:visited {
            color: #fb6542;
        }

        a:hover {
            text-decoration: none;
        }

    </style>
  </head>
  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
     	require("../../appcore/controller/controller.php");
     	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$_param = substr(strstr($req_uri, '?'), 6);
	$niveau = substr(strstr($req_uri, '&'), 8);
	$id = substr(strstr($req_uri, '&'), 4, -(strlen($niveau)+3));		
	$param = substr(substr(strstr($req_uri, '?'), 6), 0, -(strlen(substr(strstr($req_uri, '&'), 4))+4));
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];

	$notation = Controller::findOne(Util::getDb(), 'notation', 'id', $id);
	if($profile['role'] != 'admin' && $profile['role'] != 'client_b' && $profile['role'] != 'mixte') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	
  ?>
  <body>
  	<nav class="w-bgmf clearfix ">
    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
	</nav>
	 <h3>Voulez vous supprimer cette notation du locataire : <?php echo $notation['client_name'] ?>
  	 <form method="post" action=<?php echo "delete.php?user=$username" ?>>
		<input type="text" name="id" style="width:20px;" hidden value=<?php echo $id ?>>
		<hr>
		<input type="submit" value="Valider">
    </form>
    <footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
