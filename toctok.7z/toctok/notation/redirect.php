<?php
	
	$req_uri = $_SERVER['REQUEST_URI'];

	
	$param = substr(strstr($req_uri, '&'), 6); 

	if(stristr($_SERVER['REQUEST_URI'], 'notation/new.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/new.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'notation/list.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'notation/notation.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/notation.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'notation/update.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/update.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'notation/delete-view.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/notation/delete-view.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
?>
