<?php
	
	$req_uri = $_SERVER['REQUEST_URI'];

	
	$param = substr(strstr($req_uri, '&'), 6); 

	if(stristr($_SERVER['REQUEST_URI'], 'issue/new.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/new.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'issue/list.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'issue/issue.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/issue.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'issue/update.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/update.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'issue/delete-view.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/issue/delete-view.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard.php')) {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
?>
