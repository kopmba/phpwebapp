<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}

    </style>
  </head>
  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
     	require("../../appcore/controller/controller.php");
     	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	if($profile['role'] != 'admin' && $profile['role'] != 'client_a' && $profile['role'] != 'mixte') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  ?>
  <body>
  	<nav class="w-bgmf clearfix ">
    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
	</nav>
    <p>Vérifier votre numéro de tel avant la création</p>
    <form method="post" action=<?php echo "create.php?user=$username" ?>>
		<div id="model">
		   <h3>L'urgence</h3>
		   <input type="text" name="title" placeholder="Libellé"/>
		   <input type="text" name="iphone" placeholder="Votre Telephone"/>
		   <select name="category">
				<option value="">--Choisir la categorie--</option>
				<option>Electrique</option>
				<option>Electroménager</option>
				<option>Electronique</option>
				<option>Meuble</option>
				<option>Mécanique</option>
				<option>Plomberie</option>
		   </select>
		   <textarea name="description" rows="5" cols="33" placeholder="Description"></textarea>
		   <select name="level_urgency">
				<option value="">--Niveau d'urgence--</option>
				<option value="1">Normal</option>
				<option value="2">Urgent</option>
				<option value="2">Très urgent</option>
		   </select>
		</div>
		<input type="submit" value="Créer">
    </form>
    <hr>
    <form method="post">
		<input type="file" name="pictures" value="charger">
		<input type="submit" value="Upload"/>
    </form>
	<footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
