<!DOCTYPE html>
<html>
  <head>
  	<meta charset="utf-8">
    <title>Dashboard</title>
    <meta name="description" content="Tocktok app">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../assets/wcss.css">
    <style type="text/css">
    	.nav-menu {
    		text-decoration: none;
    		margin: 25px;
    	}
    	.menu-left {
		    margin-left: auto;
		}

		footer {
			margin-top: 128px;
		}

		body {
            font-family: Arial, Helvetica, sans-serif;
        }

        h1 {
            color: #375e97;
            font-size: 2em;
            font-family: Georgia, 'Times New Roman', Times, serif;
            border-bottom: 1px solid #375e97;
        }

        h2 {
            font-size: 1.5em;
        }

        .category {
            color: #999999;
            font-weight: bold;
        }

        a:link, a:visited {
            color: #fb6542;
        }

        a:hover {
            text-decoration: none;
        }

    </style>
  </head>
  <?php 
	
	require("../../appcore/config/dbconfig.php");
	require("../../appcore/config/storage.php");
	require("../../appcore/config/i18n.php");
	require("../../appcore/auth/auth.php");
     	require("../../appcore/controller/controller.php");
     	require("../../src/util/util.php");
	require('../../src/controller/auth.php');
	require('../dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";

	$_param = substr(strstr($req_uri, '?'), 6);
	//$id = substr(strstr($req_uri, '&'), 4);	
	$niveau = substr(strstr($req_uri, '&'), 8);
	$id = substr(strstr($req_uri, '&'), 4, -(strlen($niveau)+3));		
	$param = substr(substr(strstr($req_uri, '?'), 6), 0, -(strlen(substr(strstr($req_uri, '&'), 4))+4));
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data);
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	$issue = Controller::findOne(Util::getDb(), 'issue', 'id', $id);
	$files = json_decode($issue['imgdata']);
	if($profile['role'] != 'admin' && $profile['role'] != 'client_a' && $profile['role'] != 'mixte') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	
  ?>
  <body>
  	<nav class="w-bgmf clearfix ">
    	<a class="nav-menu" href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=profile/list.php&user=$username" ?>>Profils</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=issue/list.php&user=$username" ?>>Les urgences</a>
    	<a class="nav-menu" href=<?php echo "redirect.php?link=notation/list.php&user=$username" ?>>Les notations</a>
    	<a class="nav-menu manu-left" href=<?php echo "redirect.php?link=logout.php&user=$username" ?>>Deconnection</a>
	</nav>
	<div id="model">
		<h1>L'urgence : <?php echo $issue['title'] ?></h1>
		<div class="category"><?php echo $issue['category'] ?></div>
		<p><?php echo $issue['description'] ?></p>
		<h2>Contact information</h2>
        <ul>
            <li>Niveau d'urgence : <?php echo $issue['level_urgency'] ?></li>
            <li>Tel: <?php echo $issue['iphone'] ?></li>
        </ul>
		<a href=<?php echo "redirect.php?link=issue/update.php&user=$username&id=$id&niveau=$niveau" ?>></a>&nbsp;<a href=<?php echo "redirect.php?link=issue/delete-view.php&user=$username&id=$id&niveau=$niveau" ?>></a>
	</div>
  	
	<?php if($files): ?>
    <hr>
	<div id="uploads">
		<div class="w-row">
			<?php foreach($files as $key=>$value): ?>
	            <div class="w-grid-fifth">
	                <a href=<?php echo $value ?>>
	                    <img src=<?php echo $value ?> _blank==<?php echo "http://localhost:8081/toctok/dashboard/issue/imgs/$value" ?> class="img-thumbnail"/>
	                </a>
	            </div>
            <?php endforeach; ?>
        </div>
		
	</div>
	<?php endif; ?>
	<footer class="w-bgmf clearfix">
		<p style="text-align: center">Copyright Mardets</p>
	</footer>
  </body>
</html>
