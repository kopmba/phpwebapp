<?php


	class DashboardData {

		public static function queries($username) {
				
				$db = Util::getDb();
				$dbserver = $db->getDbserver();
				$profile = Controller::findOne($db, 'profile', 'username', $username);
				$issues = Controller::filter($db, 'issue', 'iphone', $profile['phone']);
				$notations = Controller::filter($db, 'notation', 'nphone', $profile['phone']);
				$profiles = Controller::find($db, 'profile');
				$data['profile'] = $profile;
				$dat['profiles'] = $profiles;
				$data['issues'] = $issues;
				$data['notations'] = $notations;
				return $data;
		}	
	
	}
?>
