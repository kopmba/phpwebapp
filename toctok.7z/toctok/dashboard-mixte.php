<!DOCTYPE html>
<html>
  <head>
  </head>
  <?php 
  
	require("../appcore/config/dbconfig.php");
	require("../appcore/config/storage.php");
	require("../appcore/config/i18n.php");
	require("../appcore/auth/auth.php");
    	require("../appcore/controller/controller.php");
    	require("../src/util/util.php");
	require('../src/controller/auth.php');
	require('dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";
	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	$profiles = $data['profiles'];
	//print_r($data['profile']['role_name']);
	$username = $data['profile']['username'];
	$fullname = $profile['fullname'];
	
	if($profile['role'] != 'client_b') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  
  ?>
  <body>             
	<h2>Bienvenue sur TocTok</h2>
	<div>
		<p>Vous avez <span><?php echo $n ?></span> parrainages.
	</div><!DOCTYPE html>
<html>
  <head>
  </head>
  <?php 
  
	require("../appcore/config/dbconfig.php");
	require("../appcore/config/storage.php");
	require("../appcore/config/i18n.php");
	require("../appcore/auth/auth.php");
    	require("../appcore/controller/controller.php");
    	require("../src/util/util.php");
	require('../src/controller/auth.php');
	require('dashboard-data.php');
	
	$lang = Util::evalUrl($_SERVER['REQUEST_URI']);
	
	$lang_fr = '&lang=fr';
	$lang_en = '&lang=en';
	$req_uri = $_SERVER['REQUEST_URI'];
	$french = "$req_uri$lang_fr";
	$eng = "$req_uri$lang_en";
	
	$param = substr(strstr($req_uri, '?'), 6); 
	$data = DashboardData::queries($param);

	$profile = $data['profile'];
	//print_r($data['profile']['role_name']);
	$username = $profile['username'];
	$fullname = $profile['fullname'];
	
	
	if($profile['role'] != 'mixte') {
		$uri = 'Location: http://localhost:8081/toctok/dashboard/dashboard.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
  
  ?>
  <body>             
	<h2>Bienvenue sur TocTok</h2>
	<div>
		<h4>Bienvenue dans votre espace TocTok</h5>
		<p>Veuillez cliquer sur les liens ci-dessous pour accéder à vos informations.</p>
	</div>
	<hr>
    <a href=<?php echo "issue/list.php?user=$username" ?>>Mes Urgences</a> | 
	<a href=<?php echo "notation/list.php?user=$username" ?>>Mes Notations</a> | 
	<a href=<?php echo "logout.php?user=$username" ?>>Se Deconnecter</a>
  </body>
</html>

