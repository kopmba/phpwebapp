<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


    echo 'payment';
?>

<div>
    <?php 

        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        //echo "List of payments";

        $db = Util::getDb();
        $payments = Controller::find($db, 'payment');

        $len = count($payments);
        echo $len;
        
        if($id != '' && $id >= 0) {
            $payments = Controller::findOne($db->getDbserver(), 'payment', 'payid', $id);
            $len = 1;
        }
       // print_r($payments);

    ?>

    <?php if($len == 1): ?>
        <?php
            $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'phone', $payments['senderid']);
        ?>
        <p>Paiement effectué par <?php echo $profile['fullname'] ?> <a href=<?php echo "payment.php?user=$username&id=$value[0]" ?>>Voir</a></p>
    <?php endif ?>

    <?php if($len > 1): ?>
        <?php foreach ($payments as $key => $value): ?>
            <?php
                $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'phone', $value['2']);
            ?>
            <p>Paiement effectué par <?php echo $profile['fullname'] ?> <a href=<?php echo "payment.php?user=$username&id=$value[0]" ?>>Voir</a></p>
        <?php endforeach ?>
    <?php endif ?>
    
</div>