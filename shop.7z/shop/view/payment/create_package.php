<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/payment.php');


?>
<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        
        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $userid);

        $db = Util::getDb();
        $package = Controller::findOne($db->getDbserver(), 'package', 'paid', $id);

    ?>

    <p>Souhaitez-vous valider ce paiement de valeur : <?php echo $package['price'] ?></p>
    <form method="post" action=<?php echo "helper/create_package.php?user=$username&id=$id" ?>>
        <p>Entrez votre numero de telephone, puis Validez!</p>
        <input type="text" name="senderid" placeholder="phone">
        <input type="text" name="amount" hidden value=<?php echo $package['price'] ?>>
        <input type="text" name="productid" hidden value=<?php echo $id ?>>
        <input type="text" name="paycode" hidden value=<?php echo date('YmdHis', time()).rand() ?>>
        <input type="submit" value="Valider"/>
        <input type="button" value="Annuler"/>
    </form>
</div>