<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/cart.php');

    

    
?>

<div>

    <?php

        session_start();

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '?'), 6);

        $_SESSION["session"]= $userid;
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);

        print_r($user);

        if($user['roleid'] == '2') {
            $uri = 'Location: http://localhost/xampp/shop/view/dashboard/dashboard-client.php';
            $url = "$uri";
            header($url);
            exit;
        }

        //List of categories
        $db = Util::getDb();
        $categories = Controller::find($db, 'category');

        //List of packages
        $packages = Controller::find($db, 'package');

        //List of products
        $products = Controller::find($db, 'product');

        //List of payments
        $payments = Controller::find($db, 'payment');

    ?>

</div>