<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/package.php');

?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $db = Util::getDb();
        $package = Controller::findOne($db->getDbserver(), 'package', 'paid', $id);
    ?>

    <p>Voulez vous supprimer ce package ?</p>
    <form method="post" action=<?php echo "helper/delete.php?user=$username&id=$id" ?>>
        <input type="text" name="paid" hidden value=<?php echo $product['paid'] ?>>
        <a class="button" href=<?php echo "list.php?user=$username" ?>>Annuler</a>
        <input type="submit" value="Supprimer"/>

    </form>
</div>