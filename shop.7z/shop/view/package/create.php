<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/package.php');


?>
<body>
    <div>
        <?php 
            session_start();
            $_SESSION["session"]='admin';
            $username = $_SESSION["session"];

            $tdb = Util::getTDb();
            $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

            $db = Util::getDb();
            $products = Controller::find($db, 'product');
        ?>

        <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
            
            <input type="text" name="pname" placeholder="Libelle">
            <input type="text" name="price" placeholder="Prix">
            <textarea type="text" name="description" placeholder="Description"></textarea>   

            <p>Ajouter un produit dans la gamme</p>
            <p><select id="product">
                <option>--Veuillez Choisir--</option>
                <?php foreach ($products as $key => $value): ?>
                    <option value=<?php echo "$value[0] $value[2]" ?>><?php echo "$value[0] $value[2]" ?></option>
                <?php endforeach ?>
            </select>  |  <input id="qty" type="text">  | <input type="button" onclick="add()" value="Ajouter"><p>
            <input id="product_list" type="text" name="products" hidden>
            <ul id="added"></ul>
            <input type="submit" value="Créer"/>
        </form>
    </div>

    <script>

        function remove(rm) {

            let id = rm.id;
            rm.parentElement.remove();
            let productsForm = document.getElementById('product_list');
            let list = JSON.parse(productsForm.value.substring(1));
            if(typeof list !== 'object') {
                list = JSON.parse(JSON.parse(productsForm.value.substring(1)));
            }
            let arrayAfterRemoving = [];
            for(i=0; i < list.length; i++) {
                if(list[i].id !== parseInt(id)) {
                    //method splice here to remove product forgotten
                    arrayAfterRemoving.push(list[i]);
                }
            }

            //mise a jour du formulaire
            productsForm.value = "&"+JSON.stringify(arrayAfterRemoving);
        }

        function add() {
            let inputSelect = document.getElementById('product')[document.getElementById('product').value].value;
            let inputList = document.getElementById('product_list');
            let qty = document.getElementById('qty').value;
            let added = document.getElementById('added');

            let pdata = {};


            pdata.id = inputSelect;
            pdata.qty = qty;

            let linode = document.createElement('li');
            let input = document.createElement('input');
            input.type = "button";
            input.value = "x";
            
            linode.textContent = '[produit : ' + inputSelect + ' | quantité : '+ qty + ']';
            input.id = inputSelect+qty;
            linode.append(input);
            let inputnode = linode.lastElementChild;
            inputnode.addEventListener('click', function() {
                remove(inputnode);
            });
            
            added.append(linode);

            let list = [];
            if(inputList.value !== '') {
                list = JSON.parse(inputList.value.substring(1));
                if(typeof list !== 'object') {
                    list = JSON.parse(JSON.parse(inputList.value.substring(1)));
                }
                list.push(pdata);
            } else {
                list.push(pdata);
            }
            
            localStorage.setItem('products', JSON.stringify(list));

            inputList.value = "&"+JSON.stringify(JSON.parse(localStorage.getItem('products')));
            localStorage.removeItem('products');
        }
    </script>
</body>