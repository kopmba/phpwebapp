<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/cart.php');

    
?>

<div>

    <?php 
    
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        print_r($profile);

        echo "List of carts";

        $db = Util::getDb();
        $cart = Controller::findOne($db->getDbserver(), 'cart', 'userid', $username);

        $products = $cart['products'];

    ?>

    <?php foreach ($products as $key => $value): ?>
        <p>name :<?php  $value['id'] ?> | qty :<?php  $value['qty'] ?></p>
    <?php endforeach ?>
    
</div>