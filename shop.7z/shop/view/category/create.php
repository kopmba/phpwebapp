<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');


?>
<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

    ?>

    <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
        <input type="text" name="name" placeholder="Libelle">   
        <textarea type="text" name="description" placeholder="Description"></textarea>   
        <input type="submit" value="Créer"/>

    </form>
</div>