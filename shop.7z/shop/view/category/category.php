<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/category.php');
    
?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);
        
        $db = Util::getDb();
        $category = Controller::findOne($db->getDbserver(), 'category', 'caid', $id);
    ?>

    <div>
        <p>The category name : <?php echo $category['name']; ?> &nbsp;&nbsp; <?php if($user['roleid'] == 1): ?>| <a href=<?php echo "edit.php?user=$username&id=$id" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$id" ?>>Supprimer</a><?php endif ?></p>
    </div>
    
</div>