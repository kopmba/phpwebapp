<?php
    
    $request_uri = $_SERVER['REQUEST_URI']; 
    $id = substr(strstr($request_uri, '&'), 4);
    $userid = substr(strstr($request_uri, '?'), 6);

    if (stristr($request_uri, 'product/list.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/list.php?user=';
        $param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'product/edit.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/edit.phpuser=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'product/create.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/edit.phpuser=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'product/delete.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/delete.phpuser=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'product/product.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/product/product.phpuser=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'payment/create_product.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/view/payment/create_product.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else if (stristr($request_uri, 'util/upload.php') == true) {

        $uri = 'Location: http://localhost/xampp/shop/src/util/upload.php?user=';
		$param = "$userid&id=$id";
		$url = "$uri$param";
		header($url);
		exit;
    }

    else {

        echo "not found url";
    }
?>