<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');

?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $db = Util::getDb();
        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
    ?>

    <p>Voulez vous supprimer le product : <?php echo $product['pname'] ?></p>
    <form method="post" action=<?php echo "helper/delete.php?user=$username&id=$id" ?>>
    <input type="text" name="pid" hidden value=<?php echo $product['pid'] ?>>
        <a class="button" href=<?php echo "list.php?user=$username" ?>>Annuler</a>
        <input type="submit" value="Supprimer"/>

    </form>
</div>