<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');


?>
<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);

        $db = Util::getDb();
        $categories = Controller::find($db, 'category');
    ?>

    <form method="post" action=<?php echo "helper/create.php?user=$username" ?>>
            
        <input type="text" name="brand" placeholder="Marque">   
        <input type="text" name="pname" placeholder="Libelle"> 
        <select name="category">
            <option>Categorie</option>
            <?php foreach ($categories as $key => $value): ?>
                <option value=<?php echo $value[0] ?>><?php echo $value[1] ?></option>
            <?php endforeach ?>
        </select>
        <input type="text" name="subcategory" placeholder="Sous Catégorie">
        <textarea type="text" name="description" placeholder="Description"></textarea>   
        <input type="text" name="price" placeholder="Prix">
        <select name="year">
            <option>Année</option>
            <option>2021</option>
            <option>2020</option>
            <option>2019</option>
            <option>2018</option>
            <option>2017</option>
            <option>2016</option>
            <option>2015</option>
            <option>2014</option>
        </select>
        <input type="number" name="qty" placeholder="Quantité">
        <input type="text" name="createdBy" hidden value=<?php echo $username ?>>
        <input type="submit" value="Créer"/>

    </form>
</div>