<?php 

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');
    require('../../src/controller/product.php');
    
?>

<div>
    <?php 
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);

        $tdb = Util::getTDb();
        $profile = Controller::findOne($tdb->getDbserver(), 'profile', 'userId', $username);
        $user = Controller::findOne($tdb->getDbserver(), 'user', 'username', $username);
        
        $db = Util::getDb();
        $product = Controller::findOne($db->getDbserver(), 'product', 'pid', $id);
    ?>

    <div>
        <p>The product name : <?php echo $product['pname']; ?> &nbsp;&nbsp; <?php if($user['roleid'] == 1): ?> <a href=<?php echo "redirect.php?link=payment/create_product.php?user=$username&id=$product[0]" ?>>Acheter</a> | <a href=<?php echo "edit.php?user=$username&id=$product[0]" ?>>Modifier</a> | <a href=<?php echo "delete.php?user=$username&id=$product[0]" ?>>Supprimer</a><?php endif ?></p>
        
        <p>
            <?php if($user['roleid'] == 1): ?>
                <a href=<?php echo "upload.php?user=$username&id=$product[0]" ?>>Ajouter</a> (Images)
            <?php endif ?>
        </p>
    </div>
    
</div>