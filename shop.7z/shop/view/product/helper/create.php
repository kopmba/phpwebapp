<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');
    require('../../../src/controller/product.php');

    ProductController::createProduct();

    $request_uri = $_SERVER['REQUEST_URI']; 
    $userid = substr(strstr($request_uri, '?'), 6);

    $uri = 'Location: http://localhost/xampp/shop/view/package/list.php?user=';
    $url = "$uri$userid";
    header($url);
    exit;


    
?>