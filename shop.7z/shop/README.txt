- T�l�charger et Installer xampp
- Lancer Xampp et d�marrer les serveurs MySQL et Apache
- Charger le repertoire shop dans htdocs
- Ouvrir le navigateur � la page : http://localhost/phpmyadmin
- Cr�er une base de donn�es et la nommer "shop"
- Charger le script de donn�es


- ouvrir le projet sur la page : http://localhost/shop  