<?php

    require('appcore/config/dbconfig.php');
    require('appcore/controller/controller.php');
    require('src/util/util.php');
?>
<div>
    <?php
        session_start();
        $_SESSION["session"]='admin';
        $username = $_SESSION["session"];

        $request_uri = $_SERVER['REQUEST_URI']; 
        $userid = substr(strstr($request_uri, '='), 1);

        $string = 'Hello World!';
        if(stristr($string, 'World') === FALSE) {
            echo '"earth" not found in string';
        }

        $enc = '{"1":"imeg.jpg"}';
        var_dump(json_decode($enc, true));
        // outputs: "earth" not found in string

    ?>
    <menu>
        <a href=<?php echo "view/category/list.php?user=$username" ?>>Categories</a> | <a href=<?php echo "view/product/list.php?user=$username" ?>>Produits</a> | <a href=<?php echo "view/package/list.php?user=$username" ?>>Packages</a> | <a href=<?php echo "view/payment/list.php?user=$username" ?>>Paiements</a>
    </menu>
</div>