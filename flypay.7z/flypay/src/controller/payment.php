<?php

     class PaymentController extends Controller {

			public static function createPayment() {
				//get db server
				$db = Util::getDb();
				
				$pid = $_POST['pid'];
				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

				$date_created = new DateTime();
				
				$payment = array();
				$payment['profileid'] = $profile['proid'];
				$payment['productid'] = $pid;
				$payment['refp'] = "#$profileid$productid$username";
				$payment['opname'] = $_POST['opname'];
				$payment['senderid'] = $_POST['senderid'];
				$payment['receiverid'] = $_POST['receiverid'];
				$payment['amount'] = $_POST['amount'] + 2000;
				$payment['created'] = $date_created->format('Y-m-d H:i:s');
				$payment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'payment', 'payid', $payment);
				
				//get the payment
				$_payment = Controller::findOne($db->getDbserver(), 'payment', 'refp', $refp);
								
				$notif = array();
				$notif['paymentid'] = $_payment['payid'];
				$notif['profileid'] = $profile['proid'];
				$notif['state'] = 0; 
				$notif['msg'] = '';
				$notif['checked'] = 0;
				$notif['created'] = $date_created->format('Y-m-d H:i:s');
				$notif['edited'] = $date_created->format('Y-m-d H:i:s');
				
				Controller::save($db, 'messagenotification', 'mnid', $notif);
				
				$arr = array();
				$arr['userid'] = $username;
				$arr['id'] = $_payment['payid'];
				return $arr;
			}

			public static function updatePayment() {
				//get db server
				$db = Util::getDb();
				$id = $_POST['id'];
				
				$payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $id);
				$old_amount = $payment['amount'];
				$new_amount = $payment['amount'] + $amount;
				
				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);
				
				$date_profile = new DateTime();
				
				$new_payment = $payment;
				
				$new_payment['amount'] = $new_amount;
				$new_payment['statut'] = $_POST['statut'];
				$new_profile['edited'] = $date_profile->format('Y-m-d H:i:s');
										 
				Controller::update($db, 'payment', 'payid', $id, $new_payment);
				$reason = '';
				
				$notif = array();
				$notif['paymentid'] = $id;
				$notif['profileid'] = $profile['proid'];
				$notif['state'] = 0; //invalid
				$notif['msg'] = $reason;
				$notif['checked'] = 0;
				$notif['created'] = $date_created->format('Y-m-d H:i:s');
				$notif['edited'] = $date_created->format('Y-m-d H:i:s');
				
				if($reason == 'Invalid') {
					$reason = "Le montant $old_amount proposé pour votre achat est inférieur au prix magasin!";
					$notif['msg'] = $reason;
				}
				
				if($reason == 'Valid') {
					$reason = "Votre produit est en cours d'acheminement!";
					$notif['msg'] = $reason;
				}
					
				
				
				Controller::save($db, 'messagenotification', 'mnid', $notif);
				
				$arr = array();
				$arr['userid'] = $username;
				$arr['id'] = $id;
				return $arr;
			}

     }

?>
