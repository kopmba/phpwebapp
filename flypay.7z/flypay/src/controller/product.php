<?php

     class ProductController extends Controller {

            

			public static function createProduct() {
				//get db server
				$db = Util::getDb();

				//remote together database server

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);

				$date_created = new DateTime();
				
				$product = array();
				$product['brand'] = $_POST['brand'];
				$product['pname'] = $_POST['pname'];
				$product['weight'] = $_POST['weight'];
				$product['qty'] = $_POST['qty'];
				$product['profileid'] = $profile['proid'];
				$product['created'] = $date_created->format('Y-m-d H:i:s');
				$product['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'product', 'pid', $product);

			}

			
     }

?>
