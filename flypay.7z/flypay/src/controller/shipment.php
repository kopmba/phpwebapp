<?php

     class ShipmentController extends Controller {

            

			public static function createShipment() {
				//get db server
				$db = Util::getDb();

				//remote together database server

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);
				
				$payid = $_POST['payid'];				
				$payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $payid);
				
				$date_created = new DateTime();
				$country = $_POST['country'];
				$city = $_POST['city'];
				$address = $_POST['address'];
				$relay_name = $_POST['relay'];
				$shipment = array();
				$shipment['paymentid'] = $payid;
				$shipment['profileid'] = $profile['proid'];
				$shipment['productid'] = $payment['productid'];
				$shipment['relay'] = "$relay_name, $address, $city, $country";
				$shipment['signature'] = 0;
				$shipment['created'] = $date_created->format('Y-m-d H:i:s');
				$shipment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::save($db, 'shipment', 'shipid', $shipment);

			}
			
			public static function editShipment() {
				//get db server
				$db = Util::getDb();

				$id = $_POST['id'];
				
				$shipment = Controller::findOne($db->getDbserver(), 'shipment', 'shipid', $id);

				$username = $_POST['userid'];
				$profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $username);
				
				$payid = $_POST['payid'];				
				$payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $payid);
				
				$date_created = new DateTime();
				
				$new_payment = $payment;				
				$new_payment['statut'] = $_POST['statut'];
				
				$new_shipment = $shipment;
				$shipment['signature'] = 1;
				$shipment['edited'] = $date_created->format('Y-m-d H:i:s');

				Controller::update($db, 'payment', 'payid', $payid, $new_payment);
				Controller::update($db, 'shipment', 'shipid', $id, $new_payment);
				
				

			}

			
     }

?>
