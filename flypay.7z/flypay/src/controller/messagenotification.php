<?php

     class MessageNotificationController extends Controller {

            public static function openMessage() {
				
				$db = Util::getDb();
				$userid = $_POST['userid'];
				$id = $_POST['id'];
				$message = Controller::findOne($db->getDbserver(), 'messagenotification', 'mnid', $id);
				
				$date_created = new DateTime();
				
				$message['checked'] = 1;
				$message['edited'] = $date_created->format('Y-m-d H:i:s');
				
				Controller::update($db, 'messagenotification', 'mnid', $id, $message);
				
				$arr = array();
				$arr['userid'] = $userid;
				$arr['payid'] = $message['payid'];
                return $arr;    
            }

    }

?>
