#Projet illustrant les pages et fonctionnalit�s du projet flypay#

D�marrer le serveur

Charger les bases de donn�es
Ajouter des profils utilisateurs en tenant compte des roles

Se connecter et naviguer