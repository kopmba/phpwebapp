<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');


?>
<!doctype html>
<html>
	<head>
		<title>Grid Style</title>
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
		<link rel="stylesheet" href="http://localhost/xampp/flypay/css/wcss.css"/>
	</head>
    <?php 

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $userid);
		
		$payment = Controller::findOne($db->getDbserver(), 'payment', 'payid', $id);
		$product = Controller::findOne($db->getDbserver(), 'product', 'productid', $payment[2]);
		
    ?>
   <body>
   <h2><a href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a></h2>
	<br>
    <h3>Valider le paiement : <?php echo $payment['refp'] ?></h3>
	
	<br>
	
	<table data-role="table" id="movie-table-custom" data-mode="reflow" class="w-body w-table w-shadow">
		  <thead>
		    <tr>
		      <th class="w-table-cell" data-priority="1">Id</th>
		      <th class="w-table-cell" style="width:40%">Ref</th>
		      <th class="w-table-cell" data-priority="2">Marque produit</th>
		      <th class="w-table-cell" data-priority="3"><abbr title="Rotten Tomato Rating">Nom du produit</abbr></th>
		      <th class="w-table-cell" data-priority="4">Poids</th>
		      <th class="w-table-cell" data-priority="5">Qté</th>
			  <th class="w-table-cell" data-priority="5">Montant</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
				  <th class="w-table-cell">1</th>
				  <td class="title"><a href="http://en.wikipedia.org/wiki/Citizen_Kane" data-rel="external"><?php echo $value[3] ?></a></td>
				  <td><b class="w-table-cell-label">Marque</b><?php echo $product[2] ?></td>
				  <td><b class="w-table-cell-label">Nom produit</b><?php echo $product[3] ?></td>
				  <td><b class="w-table-cell-label">Poids</b><?php echo $product[4] ?></td>
				  <td><b class="w-table-cell-label">Qté</b><?php echo $product[5] ?></td>
				  <td><b class="w-table-cell-label">Montant</b><?php echo $value[7] ?> xaf</td>
				</tr>
		  </tbody>
	</table>
	
	<!-- fieldset -->
	  <form>
		<div class="form-control">
			<fieldset>
				<legend>Valider un Payment</legend>
				<div class="w-row">
					<div class="w-grid-half">
						<select name="statut">
						    <option>Statut</option>
							<option>Valid</option>
							<option>Invalid</option>
						</select>
					</div>
				</div>
				<div class="w-row">
					<input type="text" name="amount" placeholder="Montant à rajouter"/>
				</div>
				
			</fieldset>
			<input type="submit" class="w-btn" value="Valider"/>
		</div>
      </form>
    </body>
</html>