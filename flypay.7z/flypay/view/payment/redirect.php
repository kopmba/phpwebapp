<?php
	
	$req_uri = $_SERVER['REQUEST_URI'];

	
	$param = substr(strstr($req_uri, '&'), 6); 

	if(stristr($_SERVER['REQUEST_URI'], 'profile/details.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/profile/details.php?user=';
		$url = "$uri$param";
		print_r($url);
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'profile/list.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/profile/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'commission/details.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/commission/details.php?user=';
		$url = "$uri$param";
		print_r($url);
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'commission/list.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/commission/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'payment/details.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/payment/details.php?user=';
		$url = "$uri$param";
		print_r($url);
		header($url);
		exit;	
	} 
	if(stristr($_SERVER['REQUEST_URI'], 'payment/list.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/payment/list.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard-admin.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/dashboard/dashboard-admin.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard-client.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/dashboard/dashboard-client.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
	if(stristr($_SERVER['REQUEST_URI'], 'dashboard/dashboard-relay.php')) {
		$uri = 'Location: http://localhost/xampp/flypay/dashboard/dashboard-relay.php?user=';
		$url = "$uri$param";
		header($url);
		exit;	
	}
?>
