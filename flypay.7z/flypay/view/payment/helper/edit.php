<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');
    require('../../../src/controller/payment.php');

    $arr = PaymentController::createPayment();

    $request_uri = $_SERVER['REQUEST_URI']; 
	
	$userid = $arr['userid'];
	$id = $arr['id'];

    $uri = 'Location: http://localhost/xampp/shop/view/payment/list.php?user=';
    $param = "$userid&id=$id";
	$url = "$uri$param";
    header($url);
    exit;


    
?>