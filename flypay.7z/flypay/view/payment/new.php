<?php

    require('../../appcore/config/dbconfig.php');
    require('../../appcore/controller/controller.php');
    require('../../src/util/util.php');


?>
<!doctype html>
<html>
	<head>
		<title>Grid Style</title>
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
		<link rel="stylesheet" href="http://localhost/xampp/flypay/css/wcss.css"/>
	</head>
    <?php 

        $request_uri = $_SERVER['REQUEST_URI']; 
        $id = substr(strstr($request_uri, '&'), 4);
        $userid = substr(strstr($request_uri, '?'), 6);
        $db = Util::getDb();
        $profile = Controller::findOne($db->getDbserver(), 'profile', 'userid', $userid);

		
    ?>
   <body>
   <h2><a href=<?php echo "redirect.php?link=dashboard/dashboard.php&user=$username" ?>>Dashboard</a></h2>
	<br>
    <h3>Nouveau payment</h3>
	
	<!-- fieldset -->
	  <form action=<?php echo "helper/create.php" ?> type="Post">
		<div class="form-control">
			<fieldset>
				<legend>Payment</legend>
				<div class="w-row">
					<input type="text" name="brand" placeholder="Marque"/>
				</div>
				<div class="w-row">
					<input type="text" name="pname" placeholder="Nom du produit"/>
				</div>
				<div class="w-row">
					<div class="w-grid-half">
						<select name="weight">
						    <option>Poids</option>
							<option>100 - 200g</option>
							<option>201 - 500g</option>
							<option>501 - 1000g</option>
							<option>1,1 - 2kg</option>
							<option>2,1 - 3kg</option>
						</select>
					</div>
					<div class="w-grid-half">
						<select name="qty">
							<option>Quantité</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</div>
				</div>
				<div class="w-row">
					<input type="text" name="amount" placeholder="Montant à payer"/>
					+2000 fcfa de frais
				</div>
				
			</fieldset>
			<input type="submit" class="w-btn" value="Valider"/>
		</div>
      </form>
    </body>
</html>