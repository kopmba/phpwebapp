<?php 

    require('../../../appcore/config/dbconfig.php');
    require('../../../appcore/controller/controller.php');
    require('../../../src/util/util.php');

	$arr = MessqgeNotificationController::openMessage();
    $request_uri = $_SERVER['REQUEST_URI']; 
    //$userid = substr(strstr($request_uri, '?'), 6);
	//$id = substr(strstr($request_uri, '&'), 4);
	$userid = $arr['userid'];
	$payid = $arr['payid'];
    $uri = 'Location: http://localhost/xampp/flypay/view/payment/details.php?user=';
    $url = "$uri$userid&id=$payid";
    header($url);
    exit;


    
?>