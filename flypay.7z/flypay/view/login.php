<!doctype html>
<html>
	<head>
		<title>Grid Style</title>
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
		<link rel="stylesheet" href="http://localhost/xampp/flybook/css/wcss.css"/>
	</head>
	<body>
		<h1>Connecter vous !</h1>
		<br>
		<!-- horizontal -->
		<div class="form-control">
			<form action="dashboard/dashboard.php" method="POST">
				
				<div class="w-row">
					<input type="text" name="username" placeholder="Username"/>
				</div>
				<br>
				<div class="w-row">
					<input type="password" name="password" placeholder="Password"/>
				</div>
				<br>
				<button style="color:green" class="btn btn-lg btn-light btn-block" type="submit">Sign in</button>
				<p class="mt-5 mb-3 text-muted">&copy; Mardets</p>
			</form>
		</div>
	</body>
</html>