-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 06 jan. 2023 à 02:56
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `flypay`
--

-- --------------------------------------------------------

--
-- Structure de la table `account`
--

CREATE TABLE `account` (
  `aid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) NOT NULL,
  `sold` double DEFAULT 0,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `commission`
--

CREATE TABLE `commission` (
  `coid` mediumint(9) NOT NULL,
  `paymentid` mediumint(9) DEFAULT NULL,
  `profileid` mediumint(9) NOT NULL,
  `accountid` mediumint(9) NOT NULL,
  `amount` double NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `invalid_payments`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `invalid_payments` (
`payid` mediumint(9)
,`profileid` mediumint(9)
,`productid` mediumint(9)
,`refp` varchar(10)
,`opname` varchar(50)
,`senderid` varchar(50)
,`receiverid` varchar(50)
,`amount` mediumint(9)
,`statut` varchar(20)
,`created` timestamp
,`edited` timestamp
);

-- --------------------------------------------------------

--
-- Structure de la table `messagenotification`
--

CREATE TABLE `messagenotification` (
  `mnid` mediumint(9) NOT NULL,
  `paymentid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) NOT NULL,
  `state` int(11) NOT NULL,
  `msg` text DEFAULT NULL,
  `checked` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `payment`
--

CREATE TABLE `payment` (
  `payid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) NOT NULL,
  `productid` mediumint(9) NOT NULL,
  `refp` varchar(10) NOT NULL,
  `opname` varchar(50) DEFAULT NULL,
  `senderid` varchar(50) DEFAULT NULL,
  `receiverid` varchar(50) DEFAULT NULL,
  `amount` mediumint(9) NOT NULL,
  `statut` varchar(20) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déclencheurs `payment`
--
DELIMITER $$
CREATE TRIGGER `add_notification` AFTER UPDATE ON `payment` FOR EACH ROW BEGIN

  

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `add_shipment` AFTER UPDATE ON `payment` FOR EACH ROW BEGIN


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `payment_last_row`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `payment_last_row` (
`payid` mediumint(9)
,`profileid` mediumint(9)
,`productid` mediumint(9)
,`opname` varchar(50)
,`senderid` varchar(50)
,`receiverid` varchar(50)
,`amount` mediumint(9)
,`created` timestamp
,`edited` timestamp
);

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `pid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) DEFAULT NULL,
  `brand` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `weight` varchar(20) DEFAULT '0',
  `qty` mediumint(9) DEFAULT 1,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `proid` mediumint(9) NOT NULL,
  `firstname` varchar(80) NOT NULL,
  `lastname` varchar(80) NOT NULL,
  `fullname` varchar(80) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `userid` varchar(80) DEFAULT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` mediumint(9) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id`, `role_name`, `description`, `created`, `edited`) VALUES
(1, 'admin', 'User allowed to updated all the contents', '2020-09-07 07:17:42', NULL),
(2, 'relay', 'Agency allowed to update specific contnets', NULL, NULL),
(3, 'user', 'User allowed to update specific contnets', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `shipment`
--

CREATE TABLE `shipment` (
  `shipid` mediumint(9) NOT NULL,
  `paymentid` mediumint(9) NOT NULL,
  `profileid` mediumint(9) NOT NULL,
  `productid` mediumint(9) NOT NULL,
  `relay` varchar(50) NOT NULL,
  `signature` tinyint(1) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL,
  `token` varchar(20) DEFAULT NULL,
  `roleid` mediumint(9) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `edited` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `email`, `password`, `token`, `roleid`, `created`, `edited`) VALUES
('admin', 'admin@homebook.org', 'admin', NULL, 1, '2022-05-10 09:54:21', '2022-05-10 09:54:21'),
('user1', 'user1@homebook.org', '123456', '', 2, '2022-05-10 09:54:21', '2022-05-10 09:54:21'),
('user2', 'user2@homebook.org', 'user', NULL, 2, '2022-05-13 11:56:13', '2022-05-13 11:56:13');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `valid_payments`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `valid_payments` (
`payid` mediumint(9)
,`profileid` mediumint(9)
,`productid` mediumint(9)
,`refp` varchar(10)
,`opname` varchar(50)
,`senderid` varchar(50)
,`receiverid` varchar(50)
,`amount` mediumint(9)
,`statut` varchar(20)
,`created` timestamp
,`edited` timestamp
);

-- --------------------------------------------------------

--
-- Structure de la vue `invalid_payments`
--
DROP TABLE IF EXISTS `invalid_payments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `invalid_payments`  AS  select `payment`.`payid` AS `payid`,`payment`.`profileid` AS `profileid`,`payment`.`productid` AS `productid`,`payment`.`refp` AS `refp`,`payment`.`opname` AS `opname`,`payment`.`senderid` AS `senderid`,`payment`.`receiverid` AS `receiverid`,`payment`.`amount` AS `amount`,`payment`.`statut` AS `statut`,`payment`.`created` AS `created`,`payment`.`edited` AS `edited` from `payment` where `payment`.`statut` = 'Invalid' ;

-- --------------------------------------------------------

--
-- Structure de la vue `payment_last_row`
--
DROP TABLE IF EXISTS `payment_last_row`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payment_last_row`  AS  select `payment`.`payid` AS `payid`,`payment`.`profileid` AS `profileid`,`payment`.`productid` AS `productid`,`payment`.`opname` AS `opname`,`payment`.`senderid` AS `senderid`,`payment`.`receiverid` AS `receiverid`,`payment`.`amount` AS `amount`,`payment`.`created` AS `created`,`payment`.`edited` AS `edited` from `payment` order by `payment`.`payid` desc limit 1 ;

-- --------------------------------------------------------

--
-- Structure de la vue `valid_payments`
--
DROP TABLE IF EXISTS `valid_payments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `valid_payments`  AS  select `payment`.`payid` AS `payid`,`payment`.`profileid` AS `profileid`,`payment`.`productid` AS `productid`,`payment`.`refp` AS `refp`,`payment`.`opname` AS `opname`,`payment`.`senderid` AS `senderid`,`payment`.`receiverid` AS `receiverid`,`payment`.`amount` AS `amount`,`payment`.`statut` AS `statut`,`payment`.`created` AS `created`,`payment`.`edited` AS `edited` from `payment` where `payment`.`statut` = 'Valid' ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`aid`);

--
-- Index pour la table `commission`
--
ALTER TABLE `commission`
  ADD PRIMARY KEY (`coid`);

--
-- Index pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  ADD PRIMARY KEY (`mnid`);

--
-- Index pour la table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payid`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Index pour la table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`proid`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `shipment`
--
ALTER TABLE `shipment`
  ADD PRIMARY KEY (`shipid`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `account`
--
ALTER TABLE `account`
  MODIFY `aid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commission`
--
ALTER TABLE `commission`
  MODIFY `coid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `messagenotification`
--
ALTER TABLE `messagenotification`
  MODIFY `mnid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `payment`
--
ALTER TABLE `payment`
  MODIFY `payid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `pid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `profile`
--
ALTER TABLE `profile`
  MODIFY `proid` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `shipment`
--
ALTER TABLE `shipment`
  MODIFY `shipid` mediumint(9) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
