<?php

    require('appcore/config/dbconfig.php');
    require('appcore/controller/controller.php');
    require('src/util/util.php');
	
	$uri = 'Location: http://localhost/xampp/flypay/view/login.php';
    $url = "$uri$userid";
    header($url);
    exit;
?>
